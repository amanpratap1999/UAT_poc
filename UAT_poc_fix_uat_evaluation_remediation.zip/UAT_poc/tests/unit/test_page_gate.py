import pytest
from unittest.mock import Mock, AsyncMock

from agent.cognition.page_gate import PageGate, PageGateResult
from agent.domain.observation import PageObservation
from agent.domain.intent import StructuredIntent
from agent.core.types import PageType

@pytest.fixture
def page_gate():
    return PageGate()

def test_home_page_url_fails(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/now/nav/ui/home",
        page_type=PageType.HOMEPAGE,
        record_number=None
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="Verify incident INC0000007 is resolved",
        target_module="incident"
    )
    
    result = page_gate.check(obs, intent)
    assert not result.passed
    assert result.expected_record == "INC0000007"
    assert result.expected_table == "incident"
    assert result.observed_page_type == "homepage"

def test_incident_form_url_passes(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/incident.do?sysparm_query=number=INC0000007",
        page_type=PageType.FORM,
        record_number="INC0000007"
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="Verify incident INC0000007 is resolved",
        target_module="incident"
    )
    
    result = page_gate.check(obs, intent)
    assert result.passed
    assert result.expected_record == "INC0000007"

def test_mismatched_record_number_fails(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/incident.do?sysparm_query=number=INC0000008",
        page_type=PageType.FORM,
        record_number="INC0000008"
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="Verify incident INC0000007 is resolved",
        target_module="incident"
    )
    
    result = page_gate.check(obs, intent)
    assert not result.passed
    assert result.expected_record == "INC0000007"
    assert result.observed_record == "INC0000008"
    assert "does not match expected target" in result.reason

def test_dialog_page_type_fails(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/some_dialog.do?number=INC0000007",
        page_type=PageType.DIALOG,
        record_number="INC0000007"
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="Verify incident INC0000007",
        target_module="incident"
    )
    
    result = page_gate.check(obs, intent)
    assert not result.passed
    assert result.expected_record == "INC0000007"
    assert result.observed_page_type == "dialog"

def test_goal_text_parsing_extracts_correctly(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/change_request.do",
        page_type=PageType.FORM,
        record_number="CHG0000123"
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="I want to approve CHG0000123 please",
        target_module="change"
    )
    
    result = page_gate.check(obs, intent)
    # The record number matches
    assert result.passed
    assert result.expected_record == "CHG0000123"
    assert result.expected_table == "change_request"

def test_goal_text_with_no_record_number_passes(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/incident.do",
        page_type=PageType.FORM,
        record_number=None
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="Create a new incident for network outage",
        target_module="incident"
    )
    
    result = page_gate.check(obs, intent)
    assert result.passed
    assert result.expected_record is None


def test_wrong_table_url_is_blocked(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/change_request.do?sys_id=abc",
        page_type=PageType.FORM,
        record_number="INC0000007",
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="Verify incident INC0000007",
        target_module="incident",
    )

    result = page_gate.check(obs, intent)

    assert not result.passed
    assert "expected ServiceNow table" in result.reason

def test_request_table_identity_is_enforced(page_gate):
    obs = PageObservation(
        url="https://instance.service-now.com/incident.do?sys_id=abc",
        page_type=PageType.FORM,
        record_number="REQ0000123",
    )
    intent = StructuredIntent(
        intent_type="GeneralValidation",
        goal="Verify request REQ0000123",
        target_module="request",
    )
    result = page_gate.check(obs, intent)
    assert not result.passed
    assert result.expected_table == "sc_request"

@pytest.mark.asyncio
async def test_navigate_to_record_uses_configured_instance_and_encoded_uri(monkeypatch, page_gate):
    from types import SimpleNamespace

    page = SimpleNamespace(goto=AsyncMock(), wait_for_timeout=AsyncMock())
    browser = SimpleNamespace(get_page=lambda: page)
    settings = SimpleNamespace(
        servicenow=SimpleNamespace(
            instance_url="https://instance.service-now.com/",
            allowed_instances=["https://instance.service-now.com"],
        )
    )
    monkeypatch.setattr("agent.core.config.get_settings", lambda: settings)

    assert await page_gate.navigate_to_record(browser, "incident", "INC0000007")
    target = page.goto.await_args.args[0]
    assert target == "https://instance.service-now.com/incident.do?sysparm_query=number=INC0000007"


@pytest.mark.asyncio
async def test_navigate_to_record_with_sys_id(monkeypatch, page_gate):
    from types import SimpleNamespace

    page = SimpleNamespace(goto=AsyncMock(), wait_for_timeout=AsyncMock())
    browser = SimpleNamespace(get_page=lambda: page)
    settings = SimpleNamespace(
        servicenow=SimpleNamespace(
            instance_url="https://instance.service-now.com/",
            allowed_instances=["https://instance.service-now.com"],
        )
    )
    monkeypatch.setattr("agent.core.config.get_settings", lambda: settings)

    assert await page_gate.navigate_to_record(
        browser, "incident", "INC0000007", sys_id="1234567890abcdef1234567890abcdef"
    )
    target = page.goto.await_args.args[0]
    assert target == "https://instance.service-now.com/incident.do?sys_id=1234567890abcdef1234567890abcdef"
