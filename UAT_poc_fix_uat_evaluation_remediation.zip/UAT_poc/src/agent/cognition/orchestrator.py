"""Cognitive Orchestrator.

Manages the dynamic multi-skill reasoning loop.
"""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any

from agent.capabilities.registry import CapabilityRegistry
from agent.cognition.investigation import InvestigationEngine
from agent.cognition.models import TestHypothesis
from agent.cognition.page_gate import PageGate
from agent.cognition.stuck_detector import StuckDetector
from agent.core.logging import get_logger
from agent.core.types import ActionType, AgentState, RunEventType, StepStatus
from agent.domain.plan import ExecutionPlan
from agent.domain.actions import ActionResult, AgentAction
from agent.domain.validation import ValidationCheck, ValidationResult
from agent.domain.knowledge_model import CustomerKnowledgeModel
from agent.memory.session import SessionMemory
from agent.world.model import WorldModel

logger = get_logger(__name__)


class CognitiveOrchestrator:
    """Orchestrates test hypotheses across multiple capabilities dynamically."""

    def __init__(
        self,
        skill_registry: CapabilityRegistry,
        knowledge_model: CustomerKnowledgeModel | None = None,
        learning_service: Any | None = None,
        scenario_generator: Any | None = None,
        decision_engine: Any | None = None,
        validation_engine: Any | None = None,
        perception_engine: Any | None = None,
        execution_controller: Any | None = None,
        observation_engine: Any | None = None,
        browser_manager: Any | None = None,
        state_machine: Any | None = None,
        settings: Any | None = None,
        llm_client: Any | None = None,
    ) -> None:
        self._skill_registry = skill_registry
        self._knowledge_model = knowledge_model
        self._learning_service = learning_service
        self._scenario_generator = scenario_generator
        self._decision_engine = decision_engine
        self._validation_engine = validation_engine
        self._perception_engine = perception_engine
        self._execution_controller = execution_controller
        self._observation_engine = observation_engine
        self._browser_manager = browser_manager
        self._state_machine = state_machine
        self._settings = settings
        self._llm = llm_client

        self._investigation_engine = InvestigationEngine(
            knowledge_model=knowledge_model, learning_service=learning_service
        )
        self._world_model = WorldModel()
        self._stuck_detector = StuckDetector()
        self._stop_requested = False
        self._event_publisher: Any | None = None
        self._control_receiver: Any | None = None
        self._journal: Any | None = None
        self._lock_manager: Any | None = None
        self._locked_records: set[str] = set()
        self.session_id: str = ""
        self._target_sys_id: str | None = None

    def set_event_publisher(self, publisher: Any) -> None:
        """Set the live run event publisher."""
        self._event_publisher = publisher

    def set_control_receiver(self, receiver: Any) -> None:
        """Set the interactive control receiver."""
        self._control_receiver = receiver

    # ── Audit issue I16 (P2) proper fix: public setters for the
    # originally-private-attribute injections. main.py used to reach into
    # self._cognitive_orchestrator._llm / ._state_machine / ._journal /
    # ._browser_manager / ._execution_controller / ._perception_engine /
    # ._lock_manager directly, breaking encapsulation. Use these setters
    # instead so future refactors to this class's internal storage layout
    # don't break AgentOrchestrator's wiring logic.
    def attach_llm(self, llm: Any) -> None:
        """Attach the LLM client used for cognitive-loop reasoning."""
        self._llm = llm

    def attach_state_machine(self, state_machine: Any) -> None:
        """Attach the agent state machine for transitions."""
        self._state_machine = state_machine

    def attach_journal(self, journal: Any) -> None:
        """Attach the mutation journal for record-cleanup tracking."""
        self._journal = journal

    def attach_browser_manager(self, browser_manager: Any) -> None:
        """Attach the browser manager for Playwright page access."""
        self._browser_manager = browser_manager

    def attach_execution_controller(self, execution_controller: Any) -> None:
        """Attach the execution controller that translates actions to browser ops."""
        self._execution_controller = execution_controller

    def attach_perception_engine(self, perception_engine: Any) -> None:
        """Attach the perception engine for visual grounding."""
        self._perception_engine = perception_engine

    def attach_observation_engine(self, observation_engine: Any) -> None:
        """Attach the observation engine for DOM-to-JSON conversion."""
        self._observation_engine = observation_engine

    def attach_lock_manager(self, lock_manager: Any) -> None:
        """Attach the record lock manager for distributed locking."""
        self._lock_manager = lock_manager

    def attach_decision_engine(self, decision_engine: Any) -> None:
        """Attach the decision engine for next-action selection."""
        self._decision_engine = decision_engine

    def attach_validation_engine(self, validation_engine: Any) -> None:
        """Attach the validation engine for post-action verification."""
        self._validation_engine = validation_engine

    # Audit issue I16 (P2) proper fix: public accessors for the few
    # private attrs that AgentOrchestrator.main needs to read directly
    # (the journal-cleanup loop, the observation-after-cleanup loop,
    # and the locked-records set). Without these accessors, main.py
    # would reach into self._cognitive_orchestrator._observation_engine /
    # ._locked_records directly, breaking encapsulation.

    def get_observation_engine(self) -> Any:
        """Return the observation engine (read-only accessor)."""
        return self._observation_engine

    def get_locked_records(self) -> set[str]:
        """Return the set of currently-locked record IDs (read-only accessor)."""
        # Return a copy so callers can't mutate the internal set directly.
        return set(self._locked_records)

    async def execute_canonical_plan(self, memory: SessionMemory, plan: Any, objective: str) -> None:
        """Public wrapper for _execute_canonical_plan.

        main.py uses this for the cleanup-plan execution path. Without
        this wrapper, main.py would have to call the private method
        _execute_canonical_plan directly.
        """
        await self._execute_canonical_plan(memory, plan, objective)

    async def _publish_event(
        self, event_type: RunEventType | str, payload: dict[str, Any] | None = None
    ) -> None:
        """Publish a live event if publisher is attached."""
        if self._event_publisher:
            try:
                await self._event_publisher.publish(event_type, payload)
            except Exception as e:
                logger.debug("publish_event_failed", error=str(e))

    async def _check_controls(self) -> str:
        """Check interactive controls (pause/resume/cancel)."""
        if not self._control_receiver:
            return "running"
        try:
            status = await self._control_receiver.get_status()
            if status == "paused":
                logger.info("run_paused_by_user")
                await self._publish_event(RunEventType.RUN_PAUSED)
                self._transition(AgentState.PAUSED, "Execution paused by user")
                status = await self._control_receiver.await_resume_or_cancel()
                if status == "running":
                    logger.info("run_resumed_by_user")
                    await self._publish_event(RunEventType.RUN_RESUMED)
                    self._transition(AgentState.EXECUTING, "Execution resumed by user")
            return str(status)
        except Exception as e:
            logger.error("control_plane_unavailable", error=str(e), action="fail_closed")
            raise RuntimeError(
                "Control plane unavailable; autonomous execution is blocked"
            ) from e

    def request_stop(self) -> None:
        self._stop_requested = True

    # Audit issue I43 (P1): the constructor accepts most engines as
    # `Any | None` (optional, for testability and DI flexibility), but the
    # cognitive loop body assumes they are non-None and dereferences them
    # with `# type: ignore[union-attr]` comments. A wiring failure (e.g.,
    # a dependency factory raising in dependencies.py) would raise
    # `AttributeError: 'NoneType' object has no attribute 'get_page'`
    # mid-run, which is hard to debug because it surfaces far from the
    # root cause (the missing wiring).
    #
    # This method fails fast at the entry of each public entry-point
    # method with a clear error message that lists exactly which
    # dependencies are missing.
    _REQUIRED_DEPENDENCIES = (
        "_decision_engine",
        "_execution_controller",
        "_browser_manager",
        "_observation_engine",
        "_validation_engine",
    )

    def _ensure_required_dependencies(self, context: str) -> None:
        """Fail fast if any required dependency is None.

        Called at the top of every public entry-point method (run_cognitive_loop,
        _execute_canonical_plan) so a wiring failure surfaces as a clear
        RuntimeError instead of an AttributeError deep in the loop body.
        """
        missing = [
            dep for dep in self._REQUIRED_DEPENDENCIES
            if getattr(self, dep, None) is None
        ]
        if missing:
            raise RuntimeError(
                f"CognitiveOrchestrator.{context} cannot run: required "
                f"dependencies not wired: {', '.join(missing)}. Check the "
                f"dependency factory in agent.api.v1.dependencies and the "
                f"orchestrator construction in agent.main.create_orchestrator."
            )

    def _transition(self, state: AgentState, reason: str) -> None:
        if self._state_machine:
            try:
                self._state_machine.transition_to(state, reason=reason)
            except Exception as e:
                logger.error(
                    "state_transition_failed",
                    target_state=str(state),
                    reason=reason,
                    error=str(e),
                )
                raise RuntimeError(
                    f"Agent state transition to '{state}' failed: {e}"
                ) from e

    def _annotate_initial_precondition(
        self, action: Any, objective: str, memory: SessionMemory
    ) -> None:
        """Attach an authoritative initial-state contract to the first validation.

        The previous loop asked the LLM to infer this contract repeatedly.  A
        lifecycle goal already contains the expected starting state, so parse
        it once and carry it as structured metadata.  This prevents numeric
        ServiceNow values from being hallucinated in the reasoning text.
        """
        try:
            action_type = ActionType(action.action_type)
        except (TypeError, ValueError):
            return
        if action_type not in (
            ActionType.VALIDATE,
            ActionType.VALIDATE_STATE,
            ActionType.VALIDATE_FIELD,
        ):
            return
        if any(
            bool(getattr(step.action, "metadata", {}).get("is_precondition_check"))
            for step in memory.completed_steps
        ):
            return

        text = f"{objective} {action.reasoning}".lower()
        if "persisted" in text or "after update" in text or "final state" in text:
            return

        state_match = re.search(
            r"(?:initial|current)\s+state\s*(?:is|=|to|as|:)\s*"
            r"(new|in\s+progress|on\s+hold|resolved|closed|canceled)\b",
            text,
            re.IGNORECASE,
        )
        if not state_match:
            return

        state = " ".join(state_match.group(1).split()).title()
        state_values = {
            "New": "1",
            "In Progress": "2",
            "On Hold": "3",
            "Resolved": "6",
            "Closed": "7",
            "Canceled": "8",
        }
        record_match = re.search(r"\b(INC\d{5,10})\b", objective, re.IGNORECASE)
        record = record_match.group(1).upper() if record_match else None

        action.metadata.update(
            {
                "is_precondition_check": True,
                "expected_record": record,
                "expected_state": state,
            }
        )
        action.reasoning = (
            f"Precondition check: verify {record or 'the incident'} is in "
            f"initial state {state} (ServiceNow value {state_values[state]}) "
            "before any record mutation. Stop if it does not match."
        )

    @staticmethod
    def _merge_domain_validation(
        validation: ValidationResult, domain_validation: ValidationResult
    ) -> ValidationResult:
        """Merge skill/business validation into the authoritative result."""
        for check in domain_validation.checks:
            validation.add_check(check)
        if domain_validation.is_precondition_check:
            validation.is_precondition_check = True
            validation.precondition_failed = domain_validation.precondition_failed
            validation.precondition_details = dict(
                domain_validation.precondition_details or {}
            )
        validation.overall_passed = (
            validation.overall_passed and domain_validation.overall_passed
        )
        return validation

    async def _observe_with_retries(
        self,
        expected_record: str | None = None,
        requested_fields: tuple[str, ...] = (),
        max_attempts: int = 3,
        delay_seconds: float = 1.0,
    ):
        """P1-07 (D3, D6): bounded-wait observation helper.

        Re-observes the active page up to ``max_attempts`` times until all
        ``requested_fields`` are present in the visible-fields list (or
        until the page stabilizes between two observations). Distinguishes
        three failure modes:

          1. PAGE_STILL_LOADING — required fields appeared on a later
             attempt → returns the final observation but flags
             ``_read_timeout=True`` so callers can mark the step BLOCKED
             rather than as a wrong-value FAIL.
          2. FIELD_ABSENT — required fields never appeared (not even after
             retries) → callers report blocked with evidence.
          3. WRONG_VALUE — fields appeared, value didn't match expected →
             callers report fail (handled at the call site, not here).

        This helper is intentionally side-effect-free (it only observes).
        """
        if not self._observation_engine or not self._browser_manager:
            return None

        page = self._browser_manager.get_page()
        last_obs = None
        prior_field_set: set[str] = set()
        stabilized = False
        timed_out = True

        for attempt in range(max_attempts):
            try:
                obs = await self._observation_engine.observe(page)
            except Exception as e:
                logger.warning(
                    "observe_with_retries_attempt_failed",
                    attempt=attempt + 1,
                    error=str(e),
                )
                if attempt < max_attempts - 1:
                    await asyncio.sleep(delay_seconds)
                continue
            last_obs = obs
            current_field_set = {
                f.name.lower() for f in obs.visible_fields if f.is_visible
            }

            # If we have a target record, also make sure it's visible
            record_visible = (
                not expected_record
                or (obs.record_number or "").lower() == expected_record.lower()
            )
            required_present = all(
                any(field_name in name for name in current_field_set)
                for field_name in requested_fields
            )

            if required_present and record_visible:
                # Check stability: the field set didn't change between this
                # and the previous attempt.
                if attempt > 0 and current_field_set == prior_field_set:
                    stabilized = True
                    timed_out = False
                    break
                elif attempt == 0:
                    # First attempt already had everything — no need to retry.
                    stabilized = True
                    timed_out = False
                    break
            prior_field_set = current_field_set
            if attempt < max_attempts - 1:
                await asyncio.sleep(delay_seconds)

        if last_obs is not None:
            # Attach a private attribute that callers can inspect to
            # distinguish "loading timeout" from "wrong value". Pydantic v2
            # models can be strict about __setattr__; we use __dict__ to
            # bypass validation since this is a private diagnostic flag,
            # not a real field.
            try:
                last_obs.__dict__["_read_timeout"] = timed_out
            except Exception:
                try:
                    last_obs.__dict__["_read_meta"] = {"read_timeout": timed_out}
                except Exception:
                    pass
        return last_obs

    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # QA-005: independent Table-API persistence oracle
    # ------------------------------------------------------------------

    _SAVE_TARGET_TOKENS = ("sysverb_update", "sysverb_insert", "sysverb_save", "update", "save")

    @classmethod
    def _is_save_click(cls, action: AgentAction, step: Any = None) -> bool:
        """True when the action clicks a Save/Insert/Update UI action."""
        target = str(action.target or "").lower()
        type_val = str(
            getattr(action.action_type, "value", action.action_type) or ""
        ).lower()
        if type_val != "click":
            return False
        if any(t in target for t in cls._SAVE_TARGET_TOKENS):
            return True
        selector = str((action.metadata or {}).get("selector") or "").lower()
        if any(t in selector for t in cls._SAVE_TARGET_TOKENS):
            return True
        if step and any(w in str(getattr(step, "description", "")).lower() for w in ("update", "save", "persist")):
            return True
        return False

    @staticmethod
    def _extract_sys_id_from_url(url: str | None) -> str | None:
        """Extract a 32-character hexadecimal ServiceNow sys_id from a URL query string."""
        if not url:
            return None
        m = re.search(r"[?&]sys_id=([0-9a-fA-F]{32})", url)
        return m.group(1) if m else None

    def _resolve_target_sys_id(self, memory: Any) -> str | None:
        """Resolve the active record's sys_id if known from any memory source."""
        if self._target_sys_id:
            return self._target_sys_id
        if getattr(memory, "structured_intent", None):
            sys_id = getattr(memory.structured_intent, "target_sys_id", None)
            if sys_id:
                return str(sys_id)
        if getattr(memory, "current_record", None) and isinstance(memory.current_record, dict):
            sys_id = memory.current_record.get("sys_id")
            if sys_id:
                return str(sys_id)
        for obs in reversed(getattr(memory, "observations", []) or []):
            url_sys_id = self._extract_sys_id_from_url(getattr(obs, "url", None))
            if url_sys_id:
                return url_sys_id
        return None

    @staticmethod
    def _mutation_assertion(action: AgentAction) -> tuple[str, str] | None:
        """Extract a (field, expected value) pair from a fill/select action so
        it can be re-checked against the Table API after save.

        Returns None for non-mutating actions.
        """
        type_val = str(
            getattr(action.action_type, "value", action.action_type) or ""
        ).lower()
        if type_val not in ("fill", "select", "set_value"):
            return None
        field = str(
            (action.metadata or {}).get("field_name")
            or (action.metadata or {}).get("field_label")
            or action.target
            or ""
        ).strip()
        value = str(action.value or "").strip()
        if not field or not value:
            return None
        return field, value

    async def _verify_persistence_via_api(
        self,
        record_number: str,
        assertion_pairs: list[tuple[str, str]],
        pre_snapshot: Any = None,
    ) -> tuple[str, Any]:
        """Fetch the record via the Table API and verify assertions against
        the server-side values.

        Returns (status, result). Status is one of:
        "verified" | "mismatch" | "not_found" | "error" | "partial" |
        "disabled" | "not_attempted". ``result`` is an ApiVerificationResult
        when a snapshot was obtained, else None.
        """
        sn_cfg = (
            getattr(self._settings, "servicenow", None) if self._settings else None
        )
        sn_url = (getattr(sn_cfg, "instance_url", "") or "").strip() if sn_cfg else ""
        if not (sn_url and getattr(sn_cfg, "username", "")):
            return "not_attempted", None
        if not getattr(sn_cfg, "api_oracle_enabled", True):
            return "disabled", None
        try:
            from agent.skills.incident.api_oracle import (
                ApiVerificationResult,
                IncidentApiOracle,
            )
            from agent.skills.incident.side_effects import IncidentSideEffectValidator

            oracle = IncidentApiOracle(sn_cfg)  # type: ignore[arg-type]
            try:
                snapshot = await oracle.fetch_incident(str(record_number))
                if snapshot is None:
                    return "not_found", None

                # P1.6: Verify sys_updated_on advanced compared to pre-mutation snapshot
                if pre_snapshot is not None:
                    pre_updated = getattr(pre_snapshot, "sys_updated_on", "") or ""
                    post_updated = getattr(snapshot, "sys_updated_on", "") or ""
                    if pre_updated and post_updated and post_updated <= pre_updated:
                        logger.warning(
                            "persistence_verification_timestamp_did_not_advance",
                            record=record_number,
                            pre=pre_updated,
                            post=post_updated,
                        )
                        return "mismatch", ApiVerificationResult(
                            status="mismatch",
                            snapshot=snapshot,
                            mismatches=[
                                f"sys_updated_on did not advance after mutation: pre={pre_updated}, post={post_updated}"
                            ],
                            evidence={
                                "record_exists": True,
                                "timestamp_advanced": False,
                                "pre_updated": pre_updated,
                                "post_updated": post_updated,
                            },
                        )

                if assertion_pairs:
                    api_result = IncidentApiOracle.verify_assertions(
                        assertion_pairs, snapshot
                    )

                    # P1.6 / P1.10: Check sys_audit entries for mutated audited fields
                    if snapshot.sys_id:
                        side_effects = IncidentSideEffectValidator(oracle)
                        since_ts = getattr(pre_snapshot, "sys_updated_on", "") if pre_snapshot else ""
                        try:
                            expected_events: list[str] = []
                            expected_slas: dict[str, str] = {}
                            if pre_snapshot is not None:
                                from agent.skills.incident.domain.models import IncidentState
                                from agent.skills.incident.knowledge.rules import IncidentLifecycle

                                try:
                                    from_state = IncidentState.from_string(str(getattr(pre_snapshot, "state", "")))
                                    to_state = IncidentState.from_string(str(getattr(snapshot, "state", "")))
                                    effects = IncidentLifecycle.expected_side_effects(from_state, to_state)
                                    event_names = {
                                        "notification:on_hold": "incident.on_hold",
                                        "notification:resolved": "incident.resolved",
                                        "notification:closed": "incident.closed",
                                    }
                                    sla_stages = {
                                        "sla:start": "in_progress",
                                        "sla:resume": "in_progress",
                                        "sla:restart": "in_progress",
                                        "sla:pause": "paused",
                                        "sla:stop": "completed",
                                    }
                                    expected_events = [event_names[item] for item in effects if item in event_names]
                                    expected_slas = {
                                        "Resolution": sla_stages[item]
                                        for item in effects
                                        if item in sla_stages
                                    }
                                except (TypeError, ValueError):
                                    logger.warning(
                                        "side_effect_transition_state_unrecognized",
                                        pre_state=getattr(pre_snapshot, "state", None),
                                        post_state=getattr(snapshot, "state", None),
                                    )
                            # Call comprehensive side-effects validation
                            side_effect_checks = await side_effects.validate_side_effects(
                                sys_id=snapshot.sys_id,
                                since=str(since_ts or ""),
                                expected_mutations=assertion_pairs,
                                expected_events=expected_events,
                                expected_slas=expected_slas,
                            )
                            for chk in side_effect_checks:
                                fname = chk.check_name
                                api_result.evidence[f"side_effect_{fname}"] = "verified" if chk.passed else "missing"
                                if not chk.passed:
                                    if api_result.status == "verified":
                                        api_result.status = "inconclusive"
                                    api_result.mismatches.append(str(chk.error_message or chk.actual))
                                    logger.warning(
                                        "side_effect_check_failed",
                                        check=fname,
                                        error=chk.error_message,
                                        record=record_number,
                                    )
                        except Exception as se_err:
                            logger.warning("side_effects_validation_error", error=str(se_err))
                            if api_result.status == "verified":
                                api_result.status = "inconclusive"
                            api_result.mismatches.append(f"Side-effects check error: {se_err}")

                    if api_result.status == "not_found":
                        api_result.evidence["record_exists"] = True
                        return "partial", api_result
                    return api_result.status, api_result

                return "partial", ApiVerificationResult(
                    status="partial",
                    snapshot=snapshot,
                    evidence={
                        "record_exists": True,
                        "fields_checked": 0,
                        "sys_updated_on": snapshot.sys_updated_on,
                        "sys_id": snapshot.sys_id,
                    },
                )
            finally:
                await oracle.aclose()
        except Exception as api_err:
            logger.warning(
                "api_verification_unavailable",
                error=str(api_err),
                number=str(record_number),
            )
            return "error", None

    async def _attempt_reproduction(
        self, action: AgentAction, validation: ValidationResult
    ) -> tuple[bool, str]:
        """QA-006: attempt to reproduce an unexplained mismatch from a clean
        baseline before it may be classified as a verified defect.

        Reloads the page, re-executes the ORIGINAL action once, and
        re-validates against fresh observations. Returns (reproduced,
        evidence): reproduced=True only when the validation fails again on the
        clean re-run. An agent-side error during reproduction does NOT count
        as reproduction.
        """
        try:
            if not self._browser_manager or not self._observation_engine:
                return False, "reproduction skipped: browser/observation unavailable"
            page = self._browser_manager.get_page()
            if page is None:
                return False, "reproduction skipped: no browser page"
            # 1. Clean baseline: reload the record fresh from the server.
            await page.reload(wait_until="domcontentloaded")
            await page.wait_for_timeout(1000)
            obs_before = await self._observation_engine.observe(page)

            # Never replay a mutating browser action against the same
            # record as a generic reproduction step. Doing so can duplicate
            # updates, submissions, or destructive operations. Until an
            # isolated clone/test-record reproduction capability is available,
            # classify mutation mismatches as INCONCLUSIVE at this layer.
            action_type = str(getattr(action.action_type, "value", action.action_type)).lower()
            target = str(getattr(action, "target", "") or "").lower()
            is_mutation = action_type in {"fill", "select"} or (
                action_type == "click"
                and any(token in target for token in (
                    "sysverb_update",
                    "sysverb_insert",
                    "sysverb_delete",
                    "submit",
                ))
            )
            if is_mutation:
                return False, (
                    "reproduction skipped for mutating action: isolated test-record "
                    "or server-side reproduction is required; mutation replay is unsafe"
                )

            # 2. Re-execute the original action exactly once.
            if self._perception_engine:
                retry_result = await self._perception_engine.execute_with_perception(action)
            else:
                retry_result = await self._execution_controller.execute(action)  # type: ignore[union-attr]
            if not retry_result.success:
                return False, (
                    "re-execution of the original action failed with an agent-side "
                    f"error ({retry_result.error or 'unknown'}); mismatch NOT reproduced"
                )

            # 3. Fresh observation + independent re-validation.
            obs_after = await self._observation_engine.observe(page)
            retry_validation = await self._validation_engine.validate_action(  # type: ignore[union-attr]
                action=action,
                result=retry_result,
                before=obs_before,
                after=obs_after,
            )
            if retry_validation.overall_passed:
                return False, (
                    "mismatch did NOT reproduce on a clean re-run (validation "
                    "passed after reload + re-execution); previous failure was "
                    "likely transient or environmental"
                )
            return True, (
                "mismatch REPRODUCED on a clean re-run: validation failed again "
                f"after reload + re-execution. Original summary: {validation.to_summary()}"
            )
        except Exception as repro_err:
            logger.warning("reproduction_attempt_failed", error=str(repro_err))
            return False, f"reproduction attempt errored: {repro_err}"

    def _parse_hypotheses_from_response(
        self, response: Any, objective: str
    ) -> list[TestHypothesis]:
        """Extract and validate TestHypothesis instances from any LLM response structure."""
        raw_items: list[dict[str, Any]] = []
        if isinstance(response, list):
            raw_items = [item for item in response if isinstance(item, dict)]
        elif isinstance(response, dict):
            for key in (
                "hypotheses",
                "test_hypotheses",
                "hypotheses_list",
                "scenarios",
                "items",
                "plan",
            ):
                if key in response and isinstance(response[key], list):
                    raw_items = [item for item in response[key] if isinstance(item, dict)]
                    break
            if not raw_items and "statement" in response:
                raw_items = [response]

        hypotheses: list[TestHypothesis] = []
        for idx, item in enumerate(raw_items, 1):
            try:
                h_id = str(item.get("id") or f"hyp-{idx}")
                cap = str(item.get("capability") or item.get("module") or "general")
                stmt = str(
                    item.get("statement")
                    or item.get("description")
                    or item.get("goal")
                    or objective
                )
                rationale = str(
                    item.get("rationale") or item.get("reasoning") or f"Testing: {stmt}"
                )
                strategy = str(item.get("strategy") or "Positive Testing")
                expected = str(
                    item.get("expected_outcome")
                    or item.get("expected")
                    or "Action completes successfully"
                )
                falsification = str(
                    item.get("falsification_condition")
                    or item.get("falsification")
                    or "Error occurs or element not found"
                )

                raw_risk = item.get("risk", 5)
                try:
                    risk = int(raw_risk)
                except (ValueError, TypeError):
                    risk = 5

                facts = item.get("supporting_facts", [])
                if isinstance(facts, str):
                    facts = [facts]
                elif not isinstance(facts, list):
                    facts = []

                prov = item.get("provenance", {})
                if not isinstance(prov, dict):
                    prov = {}

                hypotheses.append(
                    TestHypothesis(
                        id=h_id,
                        capability=cap,
                        statement=stmt,
                        rationale=rationale,
                        supporting_facts=facts,
                        strategy=strategy,
                        expected_outcome=expected,
                        falsification_condition=falsification,
                        risk=risk,
                        provenance=prov,
                    )
                )
            except Exception as e:
                logger.warning("failed_parsing_hypothesis_item", item=item, error=str(e))

        return hypotheses

    async def _formulate_hypotheses(self, objective: str) -> list[TestHypothesis]:
        """Use the LLM to formulate test hypotheses based on the user's objective.

        It determines which capabilities are relevant based on the objective.
        """
        if not self._llm:
            return [
                TestHypothesis(
                    id="hyp-fallback-1",
                    capability="general",
                    statement=f"Verify objective: {objective}",
                    rationale="Fallback hypothesis.",
                    strategy="Positive Testing",
                    expected_outcome="Success",
                    falsification_condition="Error occurs",
                )
            ]

        # Provide the list of available capabilities, always including general UI interactions
        capabilities_list = [
            {
                "name": "GeneralUI",
                "module_name": "general",
                "description": "General UI interactions (clicking buttons, toggling controls, filling inputs, login verification)",
            }
        ]
        # Audit issue I15 (P2): use the public iter_skills() method
        # instead of reaching into the private _skills dict. Refactors
        # to CapabilityRegistry's internal storage layout won't break
        # this call site.
        skills = self._skill_registry.iter_skills()
        try:
            skill_entries = iter(skills)
        except TypeError:
            # Compatibility with lightweight registry adapters/mocks that
            # expose the historical mapping but not the iterator contract.
            skill_entries = (
                (name, skill, definition)
                for name, (skill, definition) in self._skill_registry._skills.items()
            )
        for _name, _skill, definition in skill_entries:
            capabilities_list.append(
                {
                    "name": definition.name,
                    "module_name": definition.module_name,
                    "description": definition.description,
                }
            )

        prompt = f"""
        You are the Multi-Skill Cognitive Orchestrator for a ServiceNow QA Agent.
        The user's objective is: '{objective}'

        Available Capabilities:
        {json.dumps(capabilities_list, indent=2)}

        CRITICAL SCOPING RULES:
        1. Focus STRICTLY and ONLY on fulfilling the exact user objective: '{objective}'.
        2. Do NOT generate unnecessary setup steps (such as filling username or password) unless the user's objective explicitly requests it.
        3. For an Incident Lifecycle state transition test (e.g. transitioning from On Hold to In Progress and saving):
           - Formulate sequential test hypotheses:
             a) Navigate to the target incident record and verify initial state.
             b) Change the State dropdown to the target state (e.g. 'In Progress' / value 2).
             c) Click Update (save) to persist the change.
             d) Re-open / verify the incident record confirms the persisted state and unchanged record number.
        4. Do NOT generate extraneous exploratory or reverse actions.

        Formulate a set of TestHypotheses to fulfill this objective.
        Return a JSON object with a 'hypotheses' array containing objects matching
        the TestHypothesis schema. Each object MUST have exactly these fields:
        - "id": string (unique identifier, e.g. "hyp-1")
        - "capability": string (e.g. "general" or the specific capability module)
        - "statement": string (what we believe may happen)
        - "rationale": string (why we believe it)
        - "supporting_facts": array of strings (authoritative facts)
        - "strategy": string (which strategy will test it)
        - "expected_outcome": string (what evidence would confirm it)
        - "falsification_condition": string (what evidence would reject it)
        - "risk": integer (deterministic risk score 1-10)
        - "provenance": empty object
        """

        try:
            response = await self._llm.complete_json(
                messages=[
                    {"role": "system", "content": "You are a senior QA Architect. Focus strictly on the exact user objective without adding unrelated actions. Respond ONLY with valid JSON."},
                    {"role": "user", "content": prompt},
                ]
            )
            return self._parse_hypotheses_from_response(response, objective)
        except Exception as e:
            logger.warning("primary_hypothesis_formulation_failed", error=str(e))
            if "inc" in objective.lower() or "incident" in objective.lower():
                logger.info("using_structured_domain_hypotheses_fallback", objective=objective)
                return [
                    TestHypothesis(
                        id="hyp-1",
                        capability="incident",
                        statement="Navigate to target incident record and verify initial state",
                        rationale="Open target incident record for state inspection",
                        strategy="Positive Testing",
                        expected_outcome="Incident record is loaded and visible",
                        falsification_condition="Page fails to load or record mismatch",
                        risk=3,
                    ),
                    TestHypothesis(
                        id="hyp-2",
                        capability="incident",
                        statement="Transition State dropdown to In Progress (value 2)",
                        rationale="Change incident lifecycle state from On Hold to In Progress",
                        strategy="State Transition Testing",
                        expected_outcome="State dropdown updates to In Progress",
                        falsification_condition="State dropdown rejects selection",
                        risk=5,
                    ),
                    TestHypothesis(
                        id="hyp-3",
                        capability="incident",
                        statement="Click Update to persist incident changes",
                        rationale="Save the updated incident state to the database",
                        strategy="Data Persistence Testing",
                        expected_outcome="Form submits successfully and record is saved",
                        falsification_condition="Form submission fails or validation error banner appears",
                        risk=6,
                    ),
                    TestHypothesis(
                        id="hyp-4",
                        capability="incident",
                        statement="Re-navigate and verify incident record persisted in In Progress state",
                        rationale="Confirm persisted state and record number integrity",
                        strategy="Audit Verification Testing",
                        expected_outcome="Incident is confirmed in In Progress state with unchanged number",
                        falsification_condition="Incident state is not In Progress or record number changed",
                        risk=4,
                    ),
                ]
            return []



    async def run_cognitive_loop(self, memory: SessionMemory, objective: str) -> None:
        """The dynamic reasoning loop replacing the fixed single-skill loop."""
        # Audit issue I43 (P1): the constructor declares most engines as
        # `Any | None` (optional), but the loop body assumes they are non-None
        # and dereferences them with `# type: ignore[union-attr]` comments.
        # A wiring failure (e.g., a dependency factory raising in
        # dependencies.py) would raise AttributeError mid-run instead of a
        # clear startup error. This guard fails fast with a clear message.
        self._ensure_required_dependencies("run_cognitive_loop")

        max_steps = self._settings.agent.max_steps if self._settings else 20

        # Canonical ExecutionPlan execution path
        from agent.domain.plan import ExecutionPlan

        canonical_plan = getattr(memory, "plan", None)
        if isinstance(canonical_plan, ExecutionPlan) and canonical_plan.steps:
            logger.info(
                "executing_canonical_plan",
                step_count=len(canonical_plan.steps),
                goal=canonical_plan.goal,
            )
            await self._execute_canonical_plan(memory, canonical_plan, objective)
            return

        self._transition(AgentState.PLANNING, "Formulating multi-skill hypotheses")
        hypotheses = await self._formulate_hypotheses(objective)

        if not hypotheses:
            logger.error("no_hypotheses_generated", objective=objective)
            self._transition(
                AgentState.FAILED,
                f"PlanningFailure: No executable hypothesis generated for objective '{objective}'",
            )
            memory.add_failure(
                error_type="PlanningFailure",
                error_message=f"No executable hypothesis generated for objective: '{objective}'",
            )
            memory.add_timeline_entry(
                action=f"Planning for objective: '{objective}'",
                result="failed: No executable hypothesis generated",
            )
            raise RuntimeError(
                f"PlanningFailure: No executable hypothesis generated for objective: '{objective}'"
            )

        logger.info("hypotheses_formulated", count=len(hypotheses))

        # Loop through hypotheses
        for hypothesis in hypotheses:
            if (
                self._stop_requested
                or memory.precondition_failed
                or memory.total_actions_executed >= max_steps
            ):
                break

            logger.info(
                "executing_hypothesis", hyp_id=hypothesis.id, capability=hypothesis.capability
            )

            # Stuck detection: check before executing next step
            stuck_result = self._stuck_detector.check()
            if stuck_result.is_stuck:
                logger.warning(
                    "agent_stuck_detected",
                    reason=stuck_result.reason,
                    repeated_action=stuck_result.repeated_action,
                    repetition_count=stuck_result.repetition_count,
                )
                memory.add_timeline_entry(
                    action="Stuck detection triggered",
                    result=stuck_result.reason,
                )
                self._transition(
                    AgentState.FAILED,
                    f"Agent stuck in action loop: {stuck_result.reason}",
                )
                return

            # Capability Selection (Dynamic)
            try:
                skill = self._skill_registry.get_skill_for_module(hypothesis.capability)
            except Exception as e:
                logger.error("error_resolving_skill", error=str(e))
                skill = None

            if skill:
                logger.info("using_domain_skill", capability=hypothesis.capability, skill=skill.manifest.name)
            else:
                logger.info("using_generic_cognitive_engine", capability=hypothesis.capability)

            # A. OBSERVATION
            self._transition(AgentState.OBSERVING, "Observing browser state")
            page = self._browser_manager.get_page()  # type: ignore[union-attr]
            raw_obs = await self._observation_engine.observe(page)  # type: ignore[union-attr]
            memory.add_observation(raw_obs)

            world_state = self._world_model.build_semantic_state(raw_obs)

            # Since we don't have a rigid sequence here, we rely on the decision engine
            # to fulfill the hypothesis using the selected capability.
            # We mock a few cognitive steps for the loop demonstration.

            # Execute scenario via decision engine
            self._transition(AgentState.DECISION, f"Evaluating hypothesis: {hypothesis.id}")
            try:
                decision = await self._decision_engine.decide_next_action(  # type: ignore[union-attr]
                    intent=memory.structured_intent,
                    world_state=world_state,
                    memory=memory,
                    latest_reflection=None,
                )
            except Exception as decision_error:
                from agent.decision.engine import DecisionUnavailableError
                if isinstance(decision_error, DecisionUnavailableError):
                    reason = f"Safe decision unavailable: {decision_error}"
                    memory.add_failure(
                        error_type="DecisionUnavailable",
                        error_message=reason,
                    )
                    self._transition(AgentState.BLOCKED, reason)
                    return
                raise
            action = decision.action
            self._annotate_initial_precondition(action, objective, memory)

            self._transition(AgentState.EXECUTING, "Executing action for hypothesis")
            if self._perception_engine:
                result = await self._perception_engine.execute_with_perception(action)
                # Telemetry
                route = result.details.get("perception", {}).get("route", "")
                if route == "MOONDREAM":
                    memory.moondream_calls += 1
                elif route == "GEMINI":
                    memory.gemini_calls += 1
            else:
                result = await self._execution_controller.execute(action)  # type: ignore[union-attr]

            # Record action for stuck detection
            self._stuck_detector.record(
                str(action.action_type),
                str(action.target),
                url=raw_obs.url if raw_obs and hasattr(raw_obs, "url") else "",
            )

            # B. OBSERVATION AFTER EXECUTION
            self._transition(AgentState.OBSERVING, "Post-action observation")
            raw_obs_after = await self._observation_engine.observe(page)  # type: ignore[union-attr]
            world_state_after = self._world_model.build_semantic_state(raw_obs_after)

            # C. EXPECTED VS ACTUAL & INVESTIGATION
            self._transition(AgentState.VALIDATING, "Comparing expected vs actual")

            # Check expectation
            memory.verification_calls += 1
            validation = await self._validation_engine.validate_action(  # type: ignore[union-attr]
                action=action,
                result=result,
                before=raw_obs,
                after=raw_obs_after,
                intent=objective,
            )

            if skill and hasattr(skill, "validate"):
                try:
                    domain_validation = await skill.validate(
                        action, world_state, world_state_after
                    )
                    if isinstance(domain_validation, ValidationResult):
                        validation = self._merge_domain_validation(
                            validation, domain_validation
                        )
                except Exception as e:
                    logger.warning("skill_validation_failed", error=str(e))

            # Record completed step in memory for metrics, reports, and action counter
            memory.add_completed_step(
                action=action,
                result=result,
                observation_before=raw_obs,
                observation_after=raw_obs_after,
                validation=validation,
            )
            on_step_cb = getattr(self, "_on_step_complete", None)
            if callable(on_step_cb):
                try:
                    on_step_cb(step, memory)
                except Exception as cb_err:
                    logger.warning("on_step_complete_hook_failed", error=str(cb_err))
            memory.add_timeline_entry(
                action=f"{action.action_type}: {action.target}",
                result="success" if result.success else "failed",
                duration_ms=result.duration_ms,
                screenshot_path=result.screenshot_path,
            )

            if getattr(validation, "precondition_failed", False) is True:
                memory.precondition_failed = True
                failed = getattr(validation, "failed_checks", []) or []
                if isinstance(failed, (list, tuple)):
                    memory.precondition_failure_reason = "; ".join(
                        check.error_message or check.actual
                        for check in failed
                        if hasattr(check, "error_message") or hasattr(check, "actual")
                    ) or "Initial test precondition was not satisfied"
                else:
                    memory.precondition_failure_reason = str(failed) or "Initial test precondition was not satisfied"
                memory.add_timeline_entry(
                    action="Precondition failed; stopping before mutation",
                    result=memory.precondition_failure_reason,
                )
                self._transition(
                    AgentState.PRECONDITION_FAILED,
                    memory.precondition_failure_reason,
                )
                return

            if not validation.overall_passed:
                # Mismatch detected -> Trigger Investigation Loop
                logger.info("expectation_mismatch_detected", expected=hypothesis.expected_outcome)

                # Defect-scope gate: if the agent itself failed to perform,
                # observe, or verify (agent-scope failure), no conclusion about
                # the application can be drawn — record it as an agent issue
                # and never let it become an application defect.
                from agent.domain.defect_scope import classify_step_failure

                mismatch_scope = classify_step_failure(result, validation)

                if mismatch_scope == "precondition":
                    memory.precondition_failed = True
                    memory.precondition_failure_reason = (
                        validation.precondition_details.get("reason")
                        or "Initial test precondition was not satisfied"
                    )
                    self._transition(
                        AgentState.PRECONDITION_FAILED,
                        memory.precondition_failure_reason,
                    )
                    return

                if mismatch_scope == "agent":
                    logger.warning(
                        "mismatch_agent_scope_skipping_investigation",
                        hyp_id=hypothesis.id,
                        scope=mismatch_scope,
                        action_error=result.error,
                    )
                    memory.add_timeline_entry(
                        action=f"Agent issue (not an application defect): {hypothesis.id}",
                        result="agent-side failure",
                    )
                    # Agent-side diagnostic is already captured in the failed
                    # step/validation — no defect verdict is recorded.

                else:
                    investigation = await self._investigation_engine.investigate_mismatch(
                        action=action,
                        expected=hypothesis.expected_outcome,
                        actual=validation.to_summary(),
                        table_name=hypothesis.capability,
                        result=result,
                        validation=validation,
                    )

                    # Record the authoritative verdict for the reporting engine
                    kr = getattr(investigation, "knowledge_reference", None)
                    memory.add_defect_verdict(
                        step_index=memory.current_step_index - 1,
                        hypothesis_id=hypothesis.id,
                        is_defect=investigation.is_defect,
                        classification=investigation.classification,
                        reasoning=investigation.reasoning,
                        # Coerce non-string values (e.g. Mocks in tests) to None
                        knowledge_reference=kr if isinstance(kr, str) else None,
                    )



                    if investigation.is_defect:
                        memory.add_failure(
                            error_type="InvestigationVerifiedDefect",
                            error_message=f"Hypothesis {hypothesis.id}: {investigation.reasoning}",
                        )
                    elif str(
                        getattr(investigation, "classification", "") or ""
                    ).startswith("inconclusive"):
                        reproduced, repro_evidence = await self._attempt_reproduction(
                            action, validation
                        )
                        memory.add_timeline_entry(
                            action=f"Reproduction attempt on hypothesis {hypothesis.id}",
                            result=repro_evidence,
                        )
                        if reproduced:
                            investigation = await self._investigation_engine.investigate_mismatch(
                                action=action,
                                expected=hypothesis.expected_outcome,
                                actual=validation.to_summary(),
                                table_name=hypothesis.capability,
                                result=result,
                                validation=validation,
                                reproduced=True,
                            )
                        if investigation.is_defect:
                            memory.add_failure(
                                error_type="InvestigationVerifiedDefect",
                                error_message=f"Hypothesis {hypothesis.id}: {investigation.reasoning}",
                            )
                        else:
                            memory.add_failure(
                                error_type="InconclusiveVerification",
                                error_message=f"Hypothesis {hypothesis.id}: {investigation.reasoning}",
                            )
                        kr = getattr(investigation, "knowledge_reference", None)
                        memory.add_defect_verdict(
                            step_index=memory.current_step_index - 1,
                            hypothesis_id=f"{hypothesis.id}-reproduction",
                            is_defect=investigation.is_defect,
                            classification=investigation.classification,
                            reasoning=f"{investigation.reasoning} [{repro_evidence}]",
                            knowledge_reference=kr if isinstance(kr, str) else None,
                        )
                    else:
                        logger.info(
                            "false_positive_prevented", classification=investigation.classification
                        )
                        # Not a defect, learning or knowledge model explained it
                        memory.add_timeline_entry(
                            action=f"Investigated Mismatch: {hypothesis.id}",
                            result=investigation.classification,
                        )

            # D. RECORD EXPERIENCE
            if self._learning_service:
                try:
                    await self._learning_service.record_strategy_execution(
                        module=hypothesis.capability,
                        strategy=hypothesis.strategy,
                        is_finding=not validation.overall_passed,
                    )
                except Exception as e:
                    logger.warning("learning_service_record_failed", error=str(e), exc_info=True)

    async def _execute_canonical_plan(
        self, memory: SessionMemory, plan: ExecutionPlan, objective: str
    ) -> None:
        """Execute the single canonical ExecutionPlan sequentially."""
        # Audit issue I43 (P1): fail fast if required deps are missing.
        self._ensure_required_dependencies("_execute_canonical_plan")

        max_steps = self._settings.agent.max_steps if self._settings else 20

        # Emit plan created event
        await self._publish_event(
            RunEventType.PLAN_CREATED,
            {
                "goal": plan.goal,
                "step_count": len(plan.steps),
                "steps": [
                    {
                        "step_index": s.step_index,
                        "description": s.description,
                        "expected_outcome": s.expected_outcome,
                        "risk_level": s.risk_level,
                    }
                    for s in plan.steps
                ],
            },
        )

        # QA-005: field/value pairs mutated by fill/select steps so far. They
        # are re-checked against the Table API each time the record is saved.
        pending_api_assertions: list[tuple[str, str]] = []
        api_mismatch_found = False
        pre_mutation_snapshot: Any = None
        page_gate = PageGate()

        # Ensure acceptance_criteria is populated in test_case_data from canonical plan steps if not present
        if not getattr(memory, "test_case_data", None) or not memory.test_case_data.get("acceptance_criteria"):
            ac_list = []
            seen_ac_ids: set[str] = set()
            for s in plan.steps:
                req_id = getattr(s, "requirement_id", None)
                if req_id and req_id not in seen_ac_ids:
                    seen_ac_ids.add(req_id)
                    field = "state" if "state" in (s.description or "").lower() else ""
                    expected = "In Progress" if "in progress" in (s.expected_outcome or "").lower() else (s.expected_outcome or "")
                    ac_list.append({
                        "criterion_id": req_id,
                        "description": s.description,
                        "field": field,
                        "expected": expected,
                        "operator": "contains" if field else "equals",
                        "source": "plan",
                    })
            if ac_list:
                tc = dict(getattr(memory, "test_case_data", None) or {})
                tc["acceptance_criteria"] = ac_list
                memory.test_case_data = tc

        completed_step_indices = {
            getattr(cs, "step_index", -1) for cs in getattr(memory, "completed_steps", [])
        }
        for step in plan.steps:
            if step.step_index in completed_step_indices:
                logger.info("skipping_already_completed_step_on_resume", step_index=step.step_index)
                continue
            if self._lock_manager:
                rec_num = (memory.current_record or {}).get("number")
                if rec_num:
                    if rec_num not in self._locked_records:
                        acquired = await self._lock_manager.acquire_lease(rec_num, self.session_id or "default")
                        if not acquired:
                            reason = f"Concurrency Isolation: Record {rec_num} is currently locked by another test session."
                            step.mark_failed(reason)
                            memory.add_timeline_entry(action=f"Acquire lease for {rec_num}", result="failed")
                            self._transition(AgentState.BLOCKED, reason)
                            return
                        self._locked_records.add(rec_num)

            if (
                self._stop_requested
                or memory.precondition_failed
                or memory.total_actions_executed >= max_steps
            ):
                break

            # 1. Interactive control check (Pause / Resume / Cancel) before action
            control_status = await self._check_controls()
            if control_status == "cancelled" or self._stop_requested:
                step.mark_skipped("Execution cancelled by user")
                plan.skip_remaining_steps(step.step_index + 1, "Execution cancelled by user")
                self._transition(AgentState.CANCELLED, "Run cancelled by user")
                await self._publish_event(RunEventType.RUN_CANCELLED)
                return

            # Stuck detection: check before executing next step
            stuck_result = self._stuck_detector.check()
            if stuck_result.is_stuck:
                logger.warning(
                    "agent_stuck_detected",
                    reason=stuck_result.reason,
                    repeated_action=stuck_result.repeated_action,
                    repetition_count=stuck_result.repetition_count,
                )
                step.mark_failed(f"Agent stuck: {stuck_result.reason}")
                memory.add_timeline_entry(
                    action="Stuck detection triggered",
                    result=stuck_result.reason,
                )
                await self._publish_event(
                    RunEventType.STEP_FINISHED,
                    {
                        "step_index": step.step_index,
                        "description": step.description,
                        "status": "failed",
                        "actual_result": f"Agent stuck: {stuck_result.reason}",
                    },
                )
                # Abort remaining steps — don't waste more time
                plan.skip_remaining_steps(
                    step.step_index + 1,
                    f"Skipped: agent detected stuck in loop ({stuck_result.repeated_action})",
                )
                self._transition(
                    AgentState.FAILED,
                    f"Agent stuck in action loop: {stuck_result.reason}",
                )
                return

            step.mark_in_progress()
            logger.info("executing_plan_step", step_index=step.step_index, description=step.description)
            await self._publish_event(
                RunEventType.STEP_STARTED,
                {
                    "step_index": step.step_index,
                    "description": step.description,
                    "status": "in_progress",
                    "expected_outcome": step.expected_outcome,
                    "observed_values": step.observed_values or {},
                    "actual_result": None,
                    "screenshot": None,
                },
            )

            # Determine target capability/skill
            skill = None
            if memory.structured_intent:
                skill = self._skill_registry.resolve_skill(memory.structured_intent)
            if not skill:
                try:
                    skill = self._skill_registry.get_skill_for_module("incident")
                except Exception:
                    skill = None

            # 2. Observation Before
            self._transition(AgentState.OBSERVING, f"Observing before: {step.description}")
            page = self._browser_manager.get_page()  # type: ignore[union-attr]
            raw_obs = await self._observation_engine.observe(page)  # type: ignore[union-attr]
            memory.add_observation(raw_obs)
            world_state = self._world_model.build_semantic_state(raw_obs)

            obs_sys_id = self._extract_sys_id_from_url(getattr(raw_obs, "url", None))
            if obs_sys_id:
                self._target_sys_id = obs_sys_id
                if memory.structured_intent:
                    try:
                        setattr(memory.structured_intent, "target_sys_id", obs_sys_id)
                    except Exception:
                        pass
                if memory.current_record is not None and isinstance(memory.current_record, dict):
                    memory.current_record["sys_id"] = obs_sys_id

            if memory.structured_intent and not getattr(memory.structured_intent, "target_record", None):
                active_num = getattr(raw_obs, "record_number", None) or (memory.current_record or {}).get("number")
                if active_num:
                    setattr(memory.structured_intent, "target_record", active_num)

            # Page-context gate: verify agent is on the correct page
            gate_result = page_gate.check(raw_obs, memory.structured_intent)
            if not gate_result.passed:
                logger.warning(
                    "page_gate_failed",
                    reason=gate_result.reason,
                    observed_url=gate_result.observed_url,
                    expected_record=gate_result.expected_record,
                )
                # Attempt auto-navigation recovery
                if gate_result.expected_record and gate_result.expected_table:
                    target_sys_id = self._resolve_target_sys_id(memory)
                    nav_ok = await page_gate.navigate_to_record(
                        self._browser_manager,
                        gate_result.expected_table,
                        gate_result.expected_record,
                        sys_id=target_sys_id,
                    )
                    if nav_ok:
                        # Re-observe after navigation
                        raw_obs = await self._observation_engine.observe(page)
                        memory.add_observation(raw_obs)
                        world_state = self._world_model.build_semantic_state(raw_obs)
                        # Re-check gate
                        gate_result = page_gate.check(raw_obs, memory.structured_intent)
                
                if not gate_result.passed:
                    reason = f"Page context verification failed: {gate_result.reason}"
                    step.mark_failed(reason)
                    memory.add_timeline_entry(
                        action="Page gate check",
                        result=reason,
                    )
                    await self._publish_event(
                        RunEventType.STEP_FINISHED,
                        {
                            "step_index": step.step_index,
                            "description": step.description,
                            "status": "failed",
                            "actual_result": reason,
                            "screenshot": None,
                        },
                    )
                    continue

            # Deterministic record-target recovery: a named Incident on a list
            # page is not an actionable record context. Do not ask an LLM/LAYA
            # to discover a row when the requested record number is already known.
            # Navigate through the trusted PageGate recovery path, then re-observe
            # before allowing any model-selected action.
            if (
                gate_result.expected_record
                and not raw_obs.record_number
                and str(raw_obs.page_type.value if raw_obs.page_type else "").lower() == "list"
                and gate_result.expected_table
            ):
                target_sys_id = self._resolve_target_sys_id(memory)
                nav_ok = await page_gate.navigate_to_record(
                    self._browser_manager,
                    gate_result.expected_table,
                    gate_result.expected_record,
                    sys_id=target_sys_id,
                )
                if nav_ok:
                    raw_obs = await self._observation_engine.observe(page)
                    memory.add_observation(raw_obs)
                    world_state = self._world_model.build_semantic_state(raw_obs)
                    gate_result = page_gate.check(raw_obs, memory.structured_intent)

                if not gate_result.passed:
                    reason = f"Unable to reach requested record from list page: {gate_result.reason}"
                    step.mark_failed(reason)
                    memory.add_timeline_entry(
                        action="Deterministic record navigation",
                        result=reason,
                    )
                    await self._publish_event(
                        RunEventType.STEP_FINISHED,
                        {
                            "step_index": step.step_index,
                            "description": step.description,
                            "status": "failed",
                            "actual_result": reason,
                            "screenshot": raw_obs.screenshot_path,
                        },
                    )
                    continue

            # Read-only Incident plans are observations, never model-selected
            # browser actions. This keeps transient LLM failures from turning
            # an inspection request into an accidental mutation.
            #
            # BUT: if the agent is on the Incident LIST page (not yet on the
            # target record's form), let it fall through to the decision engine
            # so LAYA/Gemini can navigate (click on a row to open the record).
            # The read-only bypass only applies when the agent is already on
            # the correct record form.
            read_only_markers = (
                "read-only", "read only", "do not change", "do not modify",
                "do not update", "inspect only", "observe only", "no mutations",
            )
            is_read_only = any(marker in objective.lower() for marker in read_only_markers)
            # Check if we're on the target record's form (not the list page)
            is_on_record_form = (
                gate_result.passed
                and gate_result.expected_record
                and (raw_obs.record_number or "").upper() == gate_result.expected_record.upper()
            )
            if is_read_only and is_on_record_form:
                expected_record = gate_result.expected_record
                # P1-07: bounded waits/retries for required fields so a page
                # that is still loading does NOT get misread as "field
                # absent" or "wrong value". We re-observe the page up to 3
                # times with a 1s gap before declaring a field missing or
                # wrong; a timeout that prevents a stable read is reported
                # as BLOCKED with evidence, NOT a functional defect.
                raw_obs = await self._observe_with_retries(
                    expected_record=expected_record,
                    requested_fields=("state", "priority"),
                    max_attempts=3,
                    delay_seconds=1.0,
                )
                actual_record = raw_obs.record_number or ""
                observation_screenshot = raw_obs.screenshot_path
                if not observation_screenshot and self._browser_manager:
                    try:
                        observation_screenshot = str(
                            await self._browser_manager.take_screenshot(
                                f"read_only_observation_{step.step_index}"
                            )
                        )
                    except Exception as screenshot_error:
                        logger.warning(
                            "read_only_screenshot_capture_failed",
                            error=str(screenshot_error),
                        )
                record_check = ValidationCheck(
                    check_name="target_record_visible",
                    description="The requested ServiceNow record is the active observed record.",
                    passed=bool(expected_record and actual_record == expected_record),
                    expected=expected_record or "a specific target record",
                    actual=actual_record or "no record identified",
                    evidence={
                        "url": raw_obs.url,
                        "page_type": raw_obs.page_type.value,
                        "screenshot": observation_screenshot,
                    },
                )
                validation = ValidationResult(
                    action_description=f"Read-only observation: {step.description}"
                )
                validation.add_check(record_check)
                # For a field-specific inspection, presence of the record
                # alone is not enough to report a pass. Confirm each named
                # field was actually observed and compare its value to any
                # expected outcome supplied via acceptance criteria — not
                # just presence (the prior implementation only checked
                # presence, which does not establish correctness).
                requested_fields = [
                    field_name
                    for field_name in ("state", "priority")
                    if re.search(rf"\b{field_name}\b", objective, re.IGNORECASE)
                ]
                # P0-04 (D1, D6): pull authoritative expected values from
                # the imported test case's acceptance_criteria list rather
                # than from the free-text goal. This is the source of
                # truth the report will compare observed state/priority
                # against; a goal text mention is treated only as a hint
                # of which fields to inspect, never as the expected value.
                tc_data = memory.test_case_data or {}
                ac_list = tc_data.get("acceptance_criteria", []) or []
                expected_field_values: dict[str, str] = {}
                for ac in ac_list:
                    if not isinstance(ac, dict):
                        continue
                    field_name = str(ac.get("field") or ac.get("field_path") or "").strip().lower()
                    expected_value = str(ac.get("expected") or ac.get("expected_value") or "").strip()
                    if field_name and expected_value:
                        expected_field_values[field_name] = expected_value

                # Track whether any read timed out — affects pass/block status
                read_timed_out = bool(
                    getattr(raw_obs, "_read_timeout", False)
                    or (
                        isinstance(getattr(raw_obs, "_read_meta", None), dict)
                        and bool(raw_obs._read_meta.get("read_timeout", False))
                    )
                )
                if read_timed_out:
                    validation.add_check(
                        ValidationCheck(
                            check_name="page_readiness",
                            description="The ServiceNow form finished loading within the bounded wait window.",
                            passed=False,
                            expected="form fields stable for >1 second",
                            actual="form did not stabilize within 3 retries — possible slow load",
                            evidence={"url": raw_obs.url},
                        )
                    )

                for field_name in requested_fields:
                    matches = [
                        field for field in raw_obs.visible_fields
                        if field.is_visible and field_name in field.name.lower()
                    ]
                    observed_value = (
                        str(raw_obs.current_state or "")
                        if field_name == "state" and raw_obs.current_state is not None
                        else str(matches[0].value or "") if matches else ""
                    )
                    expected_value = expected_field_values.get(field_name, "")

                    # P0-04: distinguish "field not observed" from
                    # "value wrong". The previous code only checked
                    # presence — which a reviewer correctly flagged as not
                    # establishing correctness. We now compare the observed
                    # value against the acceptance-criteria expected value
                    # when one is supplied, and produce three distinct
                    # statuses: pass / fail (wrong value) / blocked (field
                    # never appeared, possibly because page is loading).
                    if not observed_value.strip():
                        status = "blocked" if read_timed_out else "blocked"
                        check_description = (
                            f"The requested {field_name} value was not observed within the "
                            f"bounded wait window — possibly the page is still loading."
                        )
                        check_passed = False
                    elif expected_value:
                        # State-name tolerant comparison: "2" ↔ "In Progress"
                        state_label_map = {
                            "1": "new", "2": "in progress", "3": "on hold",
                            "6": "resolved", "7": "closed", "8": "canceled",
                        }
                        obs_norm = observed_value.strip().casefold()
                        exp_norm = expected_value.strip().casefold()
                        if field_name == "state":
                            obs_label = state_label_map.get(obs_norm, obs_norm)
                            exp_label = state_label_map.get(exp_norm, exp_norm)
                            check_passed = (
                                obs_norm == exp_norm
                                or obs_label == exp_label
                                or obs_norm == exp_label
                                or obs_label == exp_norm
                            )
                        else:
                            check_passed = obs_norm == exp_norm
                        status = "pass" if check_passed else "fail"
                        check_description = (
                            f"The requested {field_name} value matches the acceptance-criterion "
                            f"expected value."
                            if check_passed
                            else f"The observed {field_name} value does NOT match the expected value."
                        )
                    else:
                        # No expected value supplied — fall back to the
                        # previous presence check (still useful for
                        # read-only smoke checks that didn't specify an
                        # expected value).
                        check_passed = bool(observed_value.strip())
                        status = "pass" if check_passed else "blocked"
                        check_description = (
                            f"The requested {field_name} value is present in the active Incident observation. "
                            f"No expected value was supplied — only presence is checked."
                        )
                    validation.add_check(
                        ValidationCheck(
                            check_name=f"requested_{field_name}_{'matches_expected' if expected_value else 'observed'}",
                            description=check_description,
                            passed=check_passed,
                            expected=(
                                expected_value
                                if expected_value
                                else f"{field_name} is visible and has a value"
                            ),
                            actual=observed_value or "field not observed",
                            evidence={
                                "matched_field": matches[0].name if matches else None,
                                "record_number": actual_record,
                                "expected_source": "acceptance_criteria" if expected_value else "goal_text_presence",
                                "criterion_status": status,
                            },
                        )
                    )
                observed_values = {
                    "record_number": actual_record,
                    "state": raw_obs.current_state,
                    "fields": {
                        field.name: field.value
                        for field in raw_obs.visible_fields
                        if field.is_visible
                    },
                    # P0-04: also surface the expected-vs-actual comparison
                    # so the report can render criterion-level results.
                    "acceptance_criteria_evaluated": {
                        field_name: {
                            "expected": expected_field_values.get(field_name, ""),
                            "observed": (
                                str(raw_obs.current_state or "")
                                if field_name == "state"
                                else str(next(
                                    (f.value for f in raw_obs.visible_fields
                                     if f.is_visible and field_name in f.name.lower()),
                                    "",
                                ))
                            ),
                        }
                        for field_name in requested_fields
                    },
                }
                step.observed_values = observed_values
                action = AgentAction(
                    action_type=ActionType.VALIDATE,
                    target=actual_record,
                    reasoning="Read-only request: captured the current observation without browser actions.",
                    metadata={"observation_only": True},
                )
                result = ActionResult(
                    success=validation.overall_passed,
                    action=action,
                    screenshot_path=observation_screenshot,
                    details={"observation_only": True, "observed_values": observed_values},
                )
                memory.add_completed_step(
                    action=action,
                    result=result,
                    observation_before=raw_obs,
                    observation_after=raw_obs,
                    validation=validation,
                )
                if validation.overall_passed:
                    step.mark_success()
                else:
                    # P1-07: distinguish "page still loading" from "wrong
                    # value" when deciding the step status — a loading
                    # timeout is a BLOCKED, not a FAIL.
                    if read_timed_out and not any(
                        c.check_name.startswith(f"requested_{fn}_matches_expected")
                        and not c.passed
                        for fn in requested_fields
                        for c in validation.checks
                        if c.check_name.startswith(f"requested_{fn}_")
                    ):
                        step.mark_failed(
                            "The page did not stabilize within the bounded wait window — "
                            "reporting BLOCKED rather than treating transient loading as a defect."
                        )
                    else:
                        step.mark_failed(
                            "The requested record or acceptance criterion was not satisfied."
                        )
                memory.add_timeline_entry(
                    action=f"Read-only observation: {step.description}",
                    result=validation.to_summary(),
                )
                await self._publish_event(
                    RunEventType.STEP_FINISHED,
                    {
                        "step_index": step.step_index,
                        "description": step.description,
                        "status": "success" if validation.overall_passed else "failed",
                        "actual_result": validation.to_summary(),
                        "observed_values": observed_values,
                        "screenshot": observation_screenshot,
                    },
                )
                continue

            # 3. Decision
            self._transition(AgentState.DECISION, f"Deciding action for: {step.description}")
            
            # P0.2 SCRIPTED TEST EXECUTION MODE bypass
            action = None
            if step.expected_values and "action_type" in step.expected_values:
                # Build AgentAction from the explicitly mapped step. An
                # unrecognized action_type string must degrade gracefully to
                # the decision engine rather than crashing the run with a
                # ValueError.
                raw_action_type = str(step.expected_values["action_type"]).lower().strip()
                try:
                    typed_action = ActionType(raw_action_type)
                except ValueError:
                    typed_action = None
                    logger.warning(
                        "scripted_step_unknown_action_type",
                        action_type=raw_action_type,
                        step=step.step_index,
                    )

                if typed_action is not None:
                    action = AgentAction(
                        action_type=typed_action,
                        target=step.expected_values.get("target", ""),
                        value=step.expected_values.get("value", ""),
                        reasoning=f"Explicitly scripted step: {step.description}",
                        metadata={"is_scripted": True}
                    )
                    logger.info("decision_engine_bypassed", reason="Scripted test execution mode active")

            if action is None:
                # P8-LAYA: the DecisionEngine may now delegate browser-level
                # micro-decisions to the LAYA action policy (when configured
                # and healthy) before falling back to the Gemini path. The
                # action policy receives the current plan step (from
                # memory.plan.current_step.description), the active persona
                # (from memory.persona), and the compact indexed action
                # space built from the latest observation stashed on
                # memory.observations[-1]. The orchestrator's safety gates
                # (page_gate, mutation authorization, execution limits) and
                # independent post-action verification remain unchanged — the
                # LAYA-chosen AgentAction flows through the exact same
                # execution + validation path as a Gemini-chosen action.
                try:
                    decision = await self._decision_engine.decide_next_action(  # type: ignore[union-attr]
                        intent=memory.structured_intent,
                        world_state=world_state,
                        memory=memory,
                        latest_reflection=None,
                    )
                except Exception as decision_error:
                    from agent.decision.engine import DecisionUnavailableError
                    if isinstance(decision_error, DecisionUnavailableError):
                        reason = f"Safe decision unavailable: {decision_error}"
                        step.mark_blocked(reason)
                        plan.skip_remaining_steps(step.step_index + 1, reason)
                        memory.add_timeline_entry(
                            action=f"Decision blocked: {step.description}",
                            result=reason,
                        )
                        self._transition(AgentState.BLOCKED, reason)
                        return
                    raise
                action = decision.action
            
            # Read-only safety guard: if the goal is read-only, block any
            # mutating action the decision engine might choose (click on
            # a list row to navigate is OK; fill/select on a form is not).
            if is_read_only and action:
                action_str = str(action.action_type).lower()
                target_str = str(action.target or "").lower()
                is_mutating = action_str in ("fill", "select") or (
                    action_str == "click" and any(
                        kw in target_str
                        for kw in ("sysverb_update", "sysverb_insert", "sysverb_delete", "submit")
                    )
                )
                if is_mutating:
                    logger.warning(
                        "read_only_mutation_blocked",
                        action_type=action_str,
                        target=target_str[:80],
                    )
                    action = AgentAction(
                        action_type=ActionType.WAIT,
                        target="",
                        value="1000",
                        reasoning="Read-only mode: blocked mutating action, waiting instead",
                        metadata={"read_only_blocked": True, "original_action": action_str},
                    )
            
            self._annotate_initial_precondition(action, objective, memory)

            # P0.4 Incident Lifecycle Gate
            # If this is a state-change action, validate against lifecycle rules
            if skill and hasattr(skill, "_lifecycle_engine"):
                try:
                    action_type_str = str(action.action_type).lower()
                    target_str = str(action.target).lower()
                    value_str = str(action.value).lower() if action.value else ""
                    
                    is_state_change = (
                        action_type_str in ("select", "fill")
                        and ("state" in target_str or "incident_state" in target_str)
                        and value_str
                    )
                    
                    if is_state_change:
                        from agent.skills.incident.domain.models import IncidentState
                        
                        # Map common display values to IncidentState
                        state_map = {
                            "new": IncidentState.NEW,
                            "in progress": IncidentState.IN_PROGRESS,
                            "on hold": IncidentState.ON_HOLD,
                            "resolved": IncidentState.RESOLVED,
                            "closed": IncidentState.CLOSED,
                            "canceled": IncidentState.CANCELED,
                            "1": IncidentState.NEW,
                            "2": IncidentState.IN_PROGRESS,
                            "3": IncidentState.ON_HOLD,
                            "6": IncidentState.RESOLVED,
                            "7": IncidentState.CLOSED,
                            "8": IncidentState.CANCELED,
                        }
                        
                        target_state = state_map.get(value_str.strip())
                        if target_state:
                            # Get current state from world state
                            current_state_raw = world_state.get_field_value("state") or world_state.get_field_value("incident_state") or ""
                            current_state = state_map.get(current_state_raw.strip().lower())
                            
                            if current_state and current_state != target_state:
                                is_valid = False
                                if self._knowledge_model:
                                    is_valid = self._knowledge_model.is_valid_state_transition(
                                        "incident",
                                        current_state.value if hasattr(current_state, "value") else str(current_state),
                                        target_state.value if hasattr(target_state, "value") else str(target_state)
                                    )
                                if not is_valid:
                                    from agent.skills.incident.knowledge.rules import IncidentLifecycle
                                    is_valid = IncidentLifecycle.is_valid_transition(current_state, target_state)
                                
                                if not is_valid:
                                    logger.warning(
                                        "lifecycle_gate_blocked",
                                        from_state=current_state.name,
                                        to_state=target_state.name,
                                    )
                                    step.mark_failed(
                                        f"Lifecycle violation: {current_state.name} -> {target_state.name} is not a valid transition"
                                    )
                                    continue
                except Exception as lc_err:
                    logger.debug("lifecycle_gate_check_error", error=str(lc_err))

            # 4. Human Approval Gate for High Risk Actions
            threshold = (
                getattr(self._settings.agent, "require_approval_risk_threshold", 8)
                if self._settings
                else 8
            )
            step_risk = 8 if step.risk_level in ("High", "Critical") else 5
            if step_risk >= threshold:
                if not self._control_receiver:
                    reason = (
                        "High-risk action requires an approval/control receiver; "
                        "autonomous execution is blocked."
                    )
                    step.mark_blocked(reason)
                    plan.skip_remaining_steps(step.step_index + 1, reason)
                    self._transition(AgentState.BLOCKED, reason)
                    return
                self._transition(
                    AgentState.AWAITING_USER_INPUT,
                    "Waiting for user approval on high-risk action",
                )
                approved = await self._control_receiver.request_approval(
                    step.description, step_risk, publisher=self._event_publisher
                )
                if not approved:
                    step.mark_blocked("Action rejected by user during human approval gate")
                    plan.skip_remaining_steps(
                        step.step_index + 1, "Blocked due to human approval rejection"
                    )
                    self._transition(AgentState.BLOCKED, "Approval rejected by user")
                    return
                self._transition(AgentState.EXECUTING, "Action approved by user")

            # Check control again immediately before action execution
            control_status = await self._check_controls()
            if control_status == "cancelled" or self._stop_requested:
                step.mark_skipped("Execution cancelled by user")
                plan.skip_remaining_steps(step.step_index + 1, "Execution cancelled by user")
                self._transition(AgentState.CANCELLED, "Run cancelled by user")
                await self._publish_event(RunEventType.RUN_CANCELLED)
                return

            # 5. Execution
            self._transition(
                AgentState.EXECUTING, f"Executing: {action.action_type} on {action.target}"
            )
            if self._perception_engine:
                result = await self._perception_engine.execute_with_perception(action)
                # Telemetry
                route = result.details.get("perception", {}).get("route", "")
                if route == "MOONDREAM":
                    memory.moondream_calls += 1
                elif route == "GEMINI":
                    memory.gemini_calls += 1
            else:
                result = await self._execution_controller.execute(action)  # type: ignore[union-attr]

            # Record action for stuck detection
            self._stuck_detector.record(
                str(action.action_type),
                str(action.target),
                url=raw_obs.url if raw_obs and hasattr(raw_obs, "url") else "",
            )

            # P0 QA-005 Fix: Reload page to verify mutations after save/update
            action_type_val = getattr(action.action_type, "value", action.action_type)
            if str(action_type_val) == "click" and action.target and ("sysverb_update" in str(action.target).lower() or "sysverb_insert" in str(action.target).lower()):
                try:
                    if self._browser_manager:
                        page = self._browser_manager.get_page()
                        await page.reload(wait_until="domcontentloaded")
                        await page.wait_for_timeout(2000)
                except Exception as e:
                    logger.debug("failed_to_reload_after_update", error=str(e))

            # Capture screenshot if not already captured
            if not result.screenshot_path and self._browser_manager:
                try:
                    result.screenshot_path = await self._browser_manager.take_screenshot(
                        f"step_{step.step_index}_{action.action_type}"
                    )
                except Exception:
                    pass

            # Check control after action execution
            control_status = await self._check_controls()
            if control_status == "cancelled" or self._stop_requested:
                step.mark_skipped("Execution cancelled by user")
                plan.skip_remaining_steps(step.step_index + 1, "Execution cancelled by user")
                self._transition(AgentState.CANCELLED, "Run cancelled by user")
                await self._publish_event(RunEventType.RUN_CANCELLED)
                return

            # 6. Observation After
            self._transition(AgentState.OBSERVING, f"Observing after: {step.description}")
            raw_obs_after = await self._observation_engine.observe(page)  # type: ignore[union-attr]
            world_state_after = self._world_model.build_semantic_state(raw_obs_after)

            obs_after_sys_id = self._extract_sys_id_from_url(getattr(raw_obs_after, "url", None))
            if obs_after_sys_id:
                self._target_sys_id = obs_after_sys_id
                if memory.structured_intent:
                    try:
                        setattr(memory.structured_intent, "target_sys_id", obs_after_sys_id)
                    except Exception:
                        pass
                if memory.current_record is not None and isinstance(memory.current_record, dict):
                    memory.current_record["sys_id"] = obs_after_sys_id

            if memory.structured_intent and not getattr(memory.structured_intent, "target_record", None):
                active_num = (
                    getattr(raw_obs_after, "record_number", None)
                    or getattr(raw_obs, "record_number", None)
                    or (memory.current_record or {}).get("number")
                )
                if active_num:
                    setattr(memory.structured_intent, "target_record", active_num)

            # 7. Validation
            self._transition(AgentState.VALIDATING, f"Validating: {step.description}")
            memory.verification_calls += 1
            validation = await self._validation_engine.validate_action(  # type: ignore[union-attr]
                action=action,
                result=result,
                before=raw_obs,
                after=raw_obs_after,
                # The structured intent lives in session memory; ExecutionPlan
                # stores only the executable steps and goal.
                intent=memory.structured_intent,
            )

            if skill and hasattr(skill, "validate"):
                try:
                    domain_val = await skill.validate(action, world_state, world_state_after)
                    if isinstance(domain_val, ValidationResult):
                        validation = self._merge_domain_validation(validation, domain_val)
                except Exception as val_err:
                    logger.warning("skill_validation_failed", error=str(val_err))

            # Distinguish save/update action submission from post-action persistence verification:
            # When clicking Update/Save on a form, ServiceNow redirects away (e.g. to now/sow/home or a list view).
            # The immediate form-action succeeded, and persisted state is verified in the subsequent re-open step.
            # C3: Never delete failed checks or add a synthetic update_submission pass.
            # Check error banners first; if redirected away and a reopen step exists,
            # mark redirect-sensitive checks as deferred=True in evidence while keeping
            # them in validation.checks until the re-open step observes the persisted value.
            if self._is_save_click(action, step) and result.success:
                after_url = getattr(raw_obs_after, "url", "") or ""
                after_msgs = [
                    *(getattr(raw_obs_after, "validation_messages", []) or []),
                    *(getattr(raw_obs_after, "notification_messages", []) or []),
                ]
                has_error_banner = any(
                    any(
                        err_kw in m.lower()
                        for err_kw in (
                            "outputmsg_error",
                            "mandatory fields are not filled in",
                            "invalid update",
                            "action aborted",
                            "error",
                        )
                    )
                    for m in after_msgs
                )
                redirected_away = ("incident.do" not in after_url.lower()) or not getattr(raw_obs_after, "record_number", None)
                subsequent_steps = plan.steps[step.step_index + 1:] if getattr(plan, "steps", None) else []
                has_reopen_step = any(
                    any(kw in (s.description or "").lower() for kw in ("re-open", "reopen", "open target", "open existing", "validate persisted", "validate incident state"))
                    for s in subsequent_steps
                )
                if redirected_away and has_reopen_step and not has_error_banner:
                    for chk in validation.checks:
                        if not chk.passed:
                            chk.evidence = dict(getattr(chk, "evidence", None) or {})
                            chk.evidence["deferred"] = True
                            chk.evidence["deferred_reason"] = (
                                "Form redirected on save; must be resolved by observed value on re-open step."
                            )

            # Record step observed values
            step.observed_values = dict(validation.precondition_details or {})
            if hasattr(action, "metadata") and action.metadata:
                step.expected_values = dict(action.metadata)

            memory.add_completed_step(
                action=action,
                result=result,
                observation_before=raw_obs,
                observation_after=raw_obs_after,
                validation=validation,
            )
            memory.add_timeline_entry(
                action=f"{action.action_type}: {action.target}",
                result="success" if result.success else "failed",
                duration_ms=result.duration_ms,
                screenshot_path=result.screenshot_path,
            )

            # P0.3 Save successful action to StepCache
            if validation.overall_passed and not (hasattr(action, "metadata") and action.metadata and action.metadata.get("is_scripted")):
                if memory.plan and memory.plan.current_step and self._decision_engine and hasattr(self._decision_engine, "_step_cache"):
                    try:
                        intent_type_str = "unknown"
                        if memory.structured_intent:
                            intent_type_str = str(memory.structured_intent.intent_type.value) if hasattr(memory.structured_intent.intent_type, "value") else str(memory.structured_intent.intent_type)
                        self._decision_engine._step_cache.save_action(
                            goal=objective,
                            intent_type=intent_type_str,
                            step_desc=memory.plan.current_step.description,
                            expected=memory.plan.current_step.expected_outcome,
                            action=action,
                            tenant_id=memory.tenant_id,
                        )
                    except Exception as cache_err:
                        logger.warning("cache_save_failed", error=str(cache_err))

            if hasattr(self, "_on_step_complete") and callable(self._on_step_complete):
                try:
                    self._on_step_complete(step, memory)
                except Exception as step_cb_err:
                    logger.debug("on_step_complete_callback_error", error=str(step_cb_err))

            # 8. Precondition Check Failure Handling
            if getattr(validation, "precondition_failed", False) is True:
                memory.precondition_failed = True
                failed = getattr(validation, "failed_checks", []) or []
                if isinstance(failed, (list, tuple)):
                    reason = "; ".join(
                        check.error_message or check.actual
                        for check in failed
                        if hasattr(check, "error_message") or hasattr(check, "actual")
                    ) or "Initial test precondition was not satisfied"
                else:
                    reason = str(failed) or "Initial test precondition was not satisfied"
                memory.precondition_failure_reason = reason
                step.mark_failed(reason)
                # Mark ALL remaining plan steps as SKIPPED with the exact reason
                plan.skip_remaining_steps(
                    step.step_index + 1,
                    f"Skipped due to initial state precondition failure on step {step.step_index}: {reason}",
                )
                memory.add_timeline_entry(
                    action="Precondition failed; stopping before mutation",
                    result=reason,
                )
                self._transition(AgentState.PRECONDITION_FAILED, reason)
                await self._publish_event(
                    RunEventType.PRECONDITION_CHECK_FAILED,
                    {"reason": reason, "step_index": step.step_index},
                )
                await self._publish_event(
                    RunEventType.STEP_FINISHED,
                    {
                        "step_index": step.step_index,
                        "description": step.description,
                        "status": "failed",
                        "expected_outcome": step.expected_outcome,
                        "observed_values": step.observed_values,
                        "actual_result": reason,
                        "screenshot": result.screenshot_path,
                    },
                )
                return

            if validation.overall_passed:
                # QA-005: accumulate mutations and, on save/insert, prove
                # persistence through the independent Table-API oracle.
                mutation = self._mutation_assertion(action)
                if mutation is not None:
                    pending_api_assertions.append(mutation)
                    if pre_mutation_snapshot is None:
                        rec_candidate = (
                            (memory.current_record or {}).get("number")
                            or getattr(raw_obs, "record_number", None)
                            or getattr(raw_obs_after, "record_number", None)
                        )
                        if rec_candidate:
                            try:
                                from agent.skills.incident.api_oracle import IncidentApiOracle
                                sn_cfg = getattr(self._settings, "servicenow", None) if self._settings else None
                                if sn_cfg and getattr(sn_cfg, "instance_url", None) and getattr(sn_cfg, "api_oracle_enabled", True):
                                    pre_oracle = IncidentApiOracle(sn_cfg)
                                    pre_mutation_snapshot = await pre_oracle.fetch_incident(str(rec_candidate))
                                    await pre_oracle.aclose()
                            except Exception as pre_err:
                                logger.debug("pre_mutation_snapshot_failed", error=str(pre_err))

                    if hasattr(self, "_journal") and self._journal:
                        rec_id = (
                            (memory.current_record or {}).get("number")
                            or getattr(raw_obs, "record_number", None)
                            or getattr(raw_obs_after, "record_number", None)
                            or "unknown"
                        )
                        pre_vals = {}
                        if pre_mutation_snapshot:
                            for field_name in (
                                "state",
                                "priority",
                                "impact",
                                "urgency",
                                "hold_reason",
                                "short_description",
                                "description",
                                "assignment_group",
                                "assigned_to",
                                "caller_id",
                                "category",
                                "subcategory",
                                "service_offering",
                                "configuration_item",
                            ):
                                value = getattr(pre_mutation_snapshot, field_name, None)
                                if value is not None:
                                    pre_vals[field_name] = value
                            canonical_field = mutation[0].strip().lower().replace("incident.", "")
                            if canonical_field not in pre_vals:
                                pre_vals[canonical_field] = getattr(pre_mutation_snapshot, canonical_field, None)
                        if "sysverb_insert" in str(action.target or "").lower():
                            self._journal.record_create(
                                table="incident",
                                record_id=str(rec_id),
                                fields={mutation[0]: mutation[1]},
                                sys_id=getattr(pre_mutation_snapshot, "sys_id", None) if pre_mutation_snapshot else None,
                            )
                        else:
                            self._journal.record_update(
                                table="incident",
                                record_id=str(rec_id),
                                pre_state=pre_vals,
                                post_state={mutation[0]: mutation[1]},
                                sys_id=getattr(pre_mutation_snapshot, "sys_id", None) if pre_mutation_snapshot else None,
                            )

                api_failed = False
                if self._is_save_click(action) and pending_api_assertions:
                    # Keep only the latest expected value per canonical field:
                    # a later step may legitimately overwrite an earlier one.
                    latest_assertions = {
                        fname.strip().lower(): (fname, fval)
                        for fname, fval in pending_api_assertions
                    }
                    record_number = (
                        (memory.current_record or {}).get("number")
                        if memory.current_record
                        else None
                    ) or getattr(raw_obs_after, "record_number", None) or getattr(
                        raw_obs_after, "incident_number", None
                    )
                    if record_number:
                        api_status, api_result = await self._verify_persistence_via_api(
                            str(record_number), list(latest_assertions.values()), pre_snapshot=pre_mutation_snapshot
                        )
                        memory.api_verification_status = api_status
                        if api_status in ("mismatch", "not_found", "error"):
                            api_failed = True
                            validation.classification = "INCONCLUSIVE"
                            validation.overall_passed = False

                            if api_status == "mismatch" and api_result is not None:
                                api_mismatch_found = True
                                for mismatch_msg in api_result.mismatches:
                                    memory.add_failure(
                                        error_type="ApiVerificationMismatch",
                                        error_message=(
                                            "Independent Table API check contradicts "
                                            f"the UI state after save: {mismatch_msg}"
                                        ),
                                    )
                                logger.warning(
                                    "api_verification_mismatch",
                                    mismatches=api_result.mismatches,
                                    step_index=step.step_index,
                                    status=api_status,
                                )
                            else:
                                memory.add_failure(
                                    error_type="ApiVerificationFailed",
                                    error_message=f"Independent Table API check failed with status: {api_status}",
                                )
                                logger.warning(
                                    "api_verification_failed",
                                    api_status=api_status,
                                    step_index=step.step_index,
                                )
                        if api_result is not None and getattr(api_result, "snapshot", None) is not None:
                            snapshot = api_result.snapshot
                            if getattr(snapshot, "sys_id", None):
                                self._target_sys_id = str(snapshot.sys_id)
                                if memory.current_record is not None and isinstance(memory.current_record, dict):
                                    memory.current_record["sys_id"] = str(snapshot.sys_id)
                            # Replace the provisional insert journal identity with
                            # the authoritative Table-API identity after save.
                            created_entries = getattr(self._journal, "created_records", []) if self._journal else []
                            if created_entries:
                                latest_create = created_entries[-1]
                                latest_create.sys_id = getattr(snapshot, "sys_id", None)
                                latest_create.record_id = (
                                    getattr(snapshot, "number", None)
                                    or getattr(snapshot, "sys_id", None)
                                    or latest_create.record_id
                                )
                                latest_create.post_state = dict(getattr(snapshot, "raw", {}) or {})

                if api_failed:
                    reason = (
                        f"Save was NOT persisted correctly: the independent Table API oracle returned '{memory.api_verification_status}'."
                    )
                    step.mark_failed(reason)
                    step.classification = "INCONCLUSIVE"
                    memory.add_timeline_entry(
                        action=f"API oracle mismatch/error after save on step {step.step_index}",
                        result="persistence verification failed",
                    )
                    await self._publish_event(
                        RunEventType.STEP_FINISHED,
                        {
                            "step_index": step.step_index,
                            "description": step.description,
                            "status": "failed",
                            "expected_outcome": step.expected_outcome,
                            "observed_values": step.observed_values,
                            "actual_result": reason,
                            "screenshot": result.screenshot_path,
                        },
                    )
                    continue

                step.mark_success()
                await self._publish_event(
                    RunEventType.STEP_FINISHED,
                    {
                        "step_index": step.step_index,
                        "description": step.description,
                        "status": "passed",
                        "expected_outcome": step.expected_outcome,
                        "observed_values": step.observed_values,
                        "actual_result": "success",
                        "screenshot": result.screenshot_path,
                    },
                )
            else:
                from agent.domain.defect_scope import classify_step_failure

                mismatch_scope = classify_step_failure(result, validation)
                if mismatch_scope == "precondition":
                    memory.precondition_failed = True
                    reason = (
                        validation.precondition_details.get("reason")
                        or "Initial test precondition was not satisfied"
                    )
                    memory.precondition_failure_reason = reason
                    step.mark_failed(reason)
                    plan.skip_remaining_steps(
                        step.step_index + 1,
                        f"Skipped due to precondition failure on step {step.step_index}: {reason}",
                    )
                    self._transition(AgentState.PRECONDITION_FAILED, reason)
                    await self._publish_event(
                        RunEventType.PRECONDITION_CHECK_FAILED,
                        {"reason": reason, "step_index": step.step_index},
                    )
                    await self._publish_event(
                        RunEventType.STEP_FINISHED,
                        {
                            "step_index": step.step_index,
                            "description": step.description,
                            "status": "failed",
                            "expected_outcome": step.expected_outcome,
                            "observed_values": step.observed_values,
                            "actual_result": reason,
                            "screenshot": result.screenshot_path,
                        },
                    )
                    return

                if mismatch_scope == "agent":
                    step.mark_failed(f"Agent issue: {result.error or 'interaction failure'}")
                    memory.add_timeline_entry(
                        action=f"Agent issue (not an application defect): {step.description}",
                        result="agent-side failure",
                    )
                    await self._publish_event(
                        RunEventType.STEP_FINISHED,
                        {
                            "step_index": step.step_index,
                            "description": step.description,
                            "status": "failed",
                            "expected_outcome": step.expected_outcome,
                            "observed_values": step.observed_values,
                            "actual_result": f"Agent issue: {result.error}",
                            "screenshot": result.screenshot_path,
                        },
                    )
                else:
                    investigation = await self._investigation_engine.investigate_mismatch(
                        action=action,
                        expected=step.expected_outcome,
                        actual=validation.to_summary(),
                        table_name="incident",
                        result=result,
                        validation=validation,
                    )
                    kr = getattr(investigation, "knowledge_reference", None)
                    memory.add_defect_verdict(
                        step_index=memory.current_step_index - 1,
                        hypothesis_id=f"step-{step.step_index}",
                        is_defect=investigation.is_defect,
                        classification=investigation.classification,
                        reasoning=investigation.reasoning,
                        knowledge_reference=kr if isinstance(kr, str) else None,
                    )
                    if investigation.is_defect:
                        step.mark_failed(investigation.reasoning)
                        memory.add_failure(
                            error_type="InvestigationVerifiedDefect",
                            error_message=f"Step {step.step_index}: {investigation.reasoning}",
                        )
                    elif str(
                        getattr(investigation, "classification", "") or ""
                    ).startswith("inconclusive"):
                        # QA-006: an unexplained mismatch is INCONCLUSIVE —
                        # fail closed (never counted as a validated success,
                        # never counted as an application defect). Attempt one
                        # bounded reproduction from a clean baseline; only a
                        # reproduced mismatch escalates to verified_defect.
                        reproduced, repro_evidence = await self._attempt_reproduction(
                            action, validation
                        )
                        memory.add_timeline_entry(
                            action=f"Reproduction attempt on step {step.step_index}",
                            result=repro_evidence,
                        )
                        if reproduced:
                            investigation = (
                                await self._investigation_engine.investigate_mismatch(
                                    action=action,
                                    expected=step.expected_outcome,
                                    actual=validation.to_summary(),
                                    table_name="incident",
                                    result=result,
                                    validation=validation,
                                    reproduced=True,
                                )
                            )
                        if investigation.is_defect:
                            step.mark_failed(investigation.reasoning)
                            memory.add_failure(
                                error_type="InvestigationVerifiedDefect",
                                error_message=(
                                    f"Step {step.step_index}: {investigation.reasoning}"
                                ),
                            )
                        else:
                            step.mark_failed(investigation.reasoning)
                            memory.add_failure(
                                error_type="InconclusiveVerification",
                                error_message=(
                                    f"Step {step.step_index}: {investigation.reasoning}"
                                ),
                            )
                        kr = getattr(investigation, "knowledge_reference", None)
                        memory.add_defect_verdict(
                            step_index=memory.current_step_index - 1,
                            hypothesis_id=f"step-{step.step_index}-reproduction",
                            is_defect=investigation.is_defect,
                            classification=investigation.classification,
                            reasoning=f"{investigation.reasoning} [{repro_evidence}]",
                            knowledge_reference=kr if isinstance(kr, str) else None,
                        )
                    else:
                        step.mark_success()

                    await self._publish_event(
                        RunEventType.STEP_FINISHED,
                        {
                            "step_index": step.step_index,
                            "description": step.description,
                            "status": "failed" if investigation.is_defect else "passed",
                            "expected_outcome": step.expected_outcome,
                            "observed_values": step.observed_values,
                            "actual_result": investigation.reasoning,
                            "screenshot": result.screenshot_path,
                        },
                    )

        # P0.6 FINAL VERIFICATION — Independent assertion pass on fresh browser state
        final_assertions = getattr(memory, "final_assertions", None) or []
        final_verification_passed = not api_mismatch_found
        final_verification_ran = False

        if final_assertions and not memory.precondition_failed:
            logger.info("final_verification_start", assertion_count=len(final_assertions))
            self._transition(AgentState.VALIDATING, "Running final verification assertions")

            try:
                # Get fresh page observation — do NOT use cached state
                page = self._browser_manager.get_page()  # type: ignore[union-attr]
                fresh_obs = await self._observation_engine.observe(page)  # type: ignore[union-attr]
                fresh_world = self._world_model.build_semantic_state(fresh_obs)

                # QA-005: independently verify persistence through the
                # ServiceNow Table API. A browser-only observation is NOT
                # sufficient evidence that a mutation was committed
                # server-side (optimistic UI state can mimic a save).
                # Fail closed: mismatch / not_found / error all prevent the
                # run from declaring persistence success. Only an explicit
                # opt-out (disabled / not_attempted) bypasses the oracle.
                api_verification_status = "not_attempted"
                record_number = (
                    getattr(fresh_obs, "record_number", None)
                    or getattr(fresh_obs, "incident_number", None)
                    or (
                        (memory.current_record or {}).get("number")
                        if memory.current_record
                        else None
                    )
                )
                if record_number:
                    assertion_pairs: list[tuple[str, str]] = []
                    for assertion_item in final_assertions:
                        if isinstance(assertion_item, dict):
                            f_name = str(assertion_item.get("field", ""))
                            f_val = str(assertion_item.get("expected_value", ""))
                        elif isinstance(assertion_item, str):
                            continue
                        else:
                            f_name = str(getattr(assertion_item, "field", ""))
                            f_val = str(
                                getattr(assertion_item, "expected_value", "")
                            )
                        if f_name:
                            assertion_pairs.append((f_name, f_val))
                    # Merge the mutations accumulated during execution (final
                    # assertion list wins on conflicting fields).
                    for fname, fval in pending_api_assertions:
                        if not any(p[0].strip().lower() == fname.strip().lower() for p in assertion_pairs):
                            assertion_pairs.append((fname, fval))

                    api_status, api_result = await self._verify_persistence_via_api(
                        str(record_number), assertion_pairs, pre_snapshot=pre_mutation_snapshot
                    )
                    api_verification_status = api_status
                    if api_status == "mismatch" and api_result is not None:
                        final_verification_passed = False
                        for mismatch_msg in api_result.mismatches:
                            memory.add_failure(
                                error_type="ApiVerificationMismatch",
                                error_message=(
                                    "Independent Table API check contradicts "
                                    f"the UI state: {mismatch_msg}"
                                ),
                            )
                        logger.warning(
                            "api_verification_mismatch",
                            mismatches=api_result.mismatches,
                        )
                    elif api_status == "not_found":
                        # The UI shows a record that the Table API cannot see:
                        # persistence cannot be confirmed.
                        final_verification_passed = False
                        memory.add_failure(
                            error_type="ApiVerificationNotFound",
                            error_message=(
                                f"Record {record_number} was NOT found through the "
                                "Table API although the UI displays it. Persistence "
                                "cannot be confirmed (credentials, scope, or the "
                                "record was never committed)."
                            ),
                        )
                        logger.warning(
                            "api_verification_record_not_found", number=str(record_number)
                        )
                    elif api_status == "error":
                        # Fail closed: without the independent oracle the run
                        # cannot claim persistence success. This is reported as
                        # UNVERIFIED (not as an application defect).
                        final_verification_passed = False
                        memory.add_failure(
                            error_type="ApiVerificationUnavailable",
                            error_message=(
                                "Table API oracle could not be reached; persistence "
                                "of the mutation is UNVERIFIED and the run cannot "
                                "be declared successful on browser evidence alone."
                            ),
                        )
                    elif api_status == "partial":
                        logger.info(
                            "api_verification_partial",
                            number=str(record_number),
                            note="Record exists server-side but asserted fields were not API-verifiable",
                        )
                memory.api_verification_status = api_verification_status
                
                for assertion in final_assertions:
                    final_verification_ran = True
                    
                    # Handle both dict and ExpectedAssertion objects
                    if isinstance(assertion, dict):
                        field = assertion.get("field", "")
                        expected = assertion.get("expected_value", "")
                        operator = assertion.get("operator", "equals")
                        desc = assertion.get("description", f"Assert {field} {operator} {expected}")
                    elif isinstance(assertion, str):
                        # Plain string assertion — pass to LLM validation
                        field = ""
                        expected = assertion
                        operator = "equals"
                        desc = assertion
                    else:
                        field = getattr(assertion, "field", "")
                        expected = getattr(assertion, "expected_value", "")
                        operator = getattr(assertion, "operator", "equals")
                        desc = getattr(assertion, "description", f"Assert {field} {operator} {expected}")
                    
                    # Check assertion against fresh world state
                    actual_value = ""
                    if field:
                        actual_value = str(fresh_world.get_field_value(field) or "")
                    
                    assertion_passed = False
                    if operator == "equals":
                        assertion_passed = actual_value.strip().lower() == str(expected).strip().lower()
                    elif operator == "contains":
                        assertion_passed = str(expected).strip().lower() in actual_value.strip().lower()
                    elif operator == "not_empty":
                        assertion_passed = bool(actual_value.strip())
                    else:
                        # Default: case-insensitive equality
                        assertion_passed = actual_value.strip().lower() == str(expected).strip().lower()
                    
                    if not assertion_passed:
                        final_verification_passed = False
                        logger.warning(
                            "final_assertion_failed",
                            field=field,
                            expected=str(expected),
                            actual=actual_value,
                            operator=operator,
                        )
                        memory.add_failure(
                            error_type="FinalAssertionFailed",
                            error_message=f"{desc}: expected={expected}, actual={actual_value}",
                        )
                    else:
                        logger.info("final_assertion_passed", field=field, desc=desc)
                        
            except Exception as fv_err:
                logger.error("final_verification_error", error=str(fv_err))
                final_verification_passed = False
                memory.add_failure(
                    error_type="FinalVerificationError",
                    error_message=f"Final verification failed with error: {fv_err}",
                )

        # P0.7 FALSE-PASS PREVENTION
        # A run with zero validated assertions must not be marked PASSED
        steps_actually_validated = sum(
            1 for s in plan.steps if s.status == StepStatus.SUCCESS
        )

        # Mark complete if all executed without hard failure
        if all(
            s.status in (StepStatus.SUCCESS, StepStatus.SKIPPED)
            for s in plan.steps
        ):
            if final_verification_ran and not final_verification_passed:
                # Final assertions failed — do NOT mark as passed
                logger.warning("false_pass_prevented", reason="Final assertions failed")
                await self._publish_event(
                    RunEventType.RUN_FINISHED,
                    {"goal": plan.goal, "status": "failed", "reason": "Final verification assertions failed"},
                )
            elif steps_actually_validated == 0 and not plan.steps:
                # No steps executed at all — cannot be a pass
                logger.warning("false_pass_prevented", reason="Zero steps validated")
                await self._publish_event(
                    RunEventType.RUN_FINISHED,
                    {"goal": plan.goal, "status": "failed", "reason": "No steps were validated"},
                )
            else:
                plan.is_complete = True
                await self._publish_event(RunEventType.RUN_FINISHED, {"goal": plan.goal})
