"""Provider-agnostic visual grounding integration."""

from __future__ import annotations

import asyncio
import base64
import io
import os
import re
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from agent.core.logging import get_logger
from agent.perception.models import BoundingBox, GroundingFailure, PerceptionCandidate
from agent.perception.parser import GroundingResponseParser

if TYPE_CHECKING:
    from playwright.async_api import Page

logger = get_logger(__name__)


class GrounderBackend(ABC):
    """Abstract interface for visual grounding providers."""

    @abstractmethod
    async def ground_element(
        self,
        screenshot_bytes: bytes,
        target_description: str,
        threshold: float = 0.8,
        frame_context: str | None = None,
        page: Page | None = None,
    ) -> PerceptionCandidate | None:
        """Locate an element visually.

        Args:
            screenshot_bytes: Raw PNG bytes.
            target_description: Natural language description.
            threshold: Confidence threshold.
            frame_context: Optional frame identifier.
            page: Playwright Page object, if the backend requires live DOM access for overlays.
        """
        pass


class LocalUiTarsBackend(GrounderBackend):
    """Backend for visual grounding via Puter's hosted UI-TARS API."""

    def __init__(self, endpoint_url: str, api_key: str | None = None) -> None:
        if not endpoint_url:
            raise ValueError("endpoint_url is required for LocalUiTarsBackend")
        self.endpoint_url = endpoint_url
        self.api_key = api_key
        self.parser = GroundingResponseParser()

    async def ground_element(
        self,
        screenshot_bytes: bytes,
        target_description: str,
        threshold: float = 0.8,
        frame_context: str | None = None,
        page: Page | None = None,
    ) -> PerceptionCandidate | None:
        import httpx

        annotated_bytes = self._annotate_screenshot(screenshot_bytes)
        b64_image = base64.b64encode(annotated_bytes).decode("utf-8")

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "model": "bytedance/ui-tars-1.5-7b",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": target_description},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{b64_image}"},
                        },
                    ],
                }
            ],
            "temperature": 0.1,
            "max_tokens": 1024,
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(self.endpoint_url, json=payload, headers=headers)
                response.raise_for_status()
                data = response.json()
        except Exception as e:
            raise GroundingFailure(f"Puter API error: {e}") from e

        result = self.parser.parse_response(data, threshold=threshold)
        if not result:
            return None

        return PerceptionCandidate(
            source="vision",
            target_description=target_description,
            confidence=result.confidence,
            bounding_box=BoundingBox(
                x=result.x,
                y=result.y,
                width=result.width,
                height=result.height,
            ),
            frame_context=frame_context,
            label=result.label,
        )

    def _annotate_screenshot(self, screenshot_bytes: bytes) -> bytes:
        try:
            from PIL import Image

            image = Image.open(io.BytesIO(screenshot_bytes))
            out_bytes = io.BytesIO()
            image.save(out_bytes, format="PNG")
            return out_bytes.getvalue()
        except Exception:
            return screenshot_bytes


class MoondreamBackend(GrounderBackend):
    """Backend for Moondream visual grounding."""

    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or os.environ.get("MOONDREAM_API_KEY")
        if not self.api_key:
            raise ValueError("MOONDREAM_API_KEY is required")
        import moondream as md  # type: ignore[import-untyped]

        self.model = md.vl(api_key=self.api_key)

    async def ground_element(
        self,
        screenshot_bytes: bytes,
        target_description: str,
        threshold: float = 0.8,
        frame_context: str | None = None,
        page: Page | None = None,
    ) -> PerceptionCandidate | None:
        from PIL import Image

        img = Image.open(io.BytesIO(screenshot_bytes)).convert("RGB")
        width, height = img.size

        logger.info(
            "perception_started",
            provider="moondream",
            task="ground_element",
            target=target_description,
        )

        try:
            encoded = self.model.encode_image(img)

            # Detect
            logger.info("moondream_inference_started", target=target_description, task="detect")
            detect_res = self.model.detect(encoded, target_description)
            if hasattr(detect_res, "objects") and detect_res.objects:
                obj = detect_res.objects[0]
                bbox = BoundingBox(
                    x=int(obj.x_min * width),
                    y=int(obj.y_min * height),
                    width=int((obj.x_max - obj.x_min) * width),
                    height=int((obj.y_max - obj.y_min) * height),
                )
                logger.info(
                    "moondream_detect_success",
                    target=target_description,
                    confidence=0.65,
                    center_x=bbox.center_x,
                    center_y=bbox.center_y,
                )
                logger.info(
                    "perception_completed",
                    provider="moondream",
                    target=target_description,
                    success=True,
                    method="detect",
                )
                return PerceptionCandidate(
                    source="moondream",
                    target_description=target_description,
                    confidence=0.65,
                    bounding_box=bbox,
                    frame_context=frame_context,
                )
            elif isinstance(detect_res, dict) and detect_res.get("objects"):
                obj = detect_res["objects"][0]
                bbox = BoundingBox(
                    x=int(obj["x_min"] * width),
                    y=int(obj["y_min"] * height),
                    width=int((obj["x_max"] - obj["x_min"]) * width),
                    height=int((obj["y_max"] - obj["y_min"]) * height),
                )
                logger.info(
                    "moondream_detect_success",
                    target=target_description,
                    confidence=0.65,
                    center_x=bbox.center_x,
                    center_y=bbox.center_y,
                )
                logger.info(
                    "perception_completed",
                    provider="moondream",
                    target=target_description,
                    success=True,
                    method="detect",
                )
                return PerceptionCandidate(
                    source="moondream",
                    target_description=target_description,
                    confidence=0.65,
                    bounding_box=bbox,
                    frame_context=frame_context,
                )

            # Point Fallback
            logger.info("moondream_inference_started", target=target_description, task="point")
            point_res = self.model.point(encoded, target_description)
            pt = None
            if hasattr(point_res, "points") and point_res.points:
                pt = point_res.points[0]
                x, y = pt.x, pt.y
            elif isinstance(point_res, dict) and point_res.get("points"):
                x, y = point_res["points"][0]["x"], point_res["points"][0]["y"]

            if pt or (isinstance(point_res, dict) and point_res.get("points")):
                px, py = int(x * width), int(y * height)
                logger.info(
                    "moondream_point_success",
                    target=target_description,
                    x=px,
                    y=py,
                )
                logger.info(
                    "perception_completed",
                    provider="moondream",
                    target=target_description,
                    success=True,
                    method="point",
                )
                return PerceptionCandidate(
                    source="moondream",
                    target_description=target_description,
                    confidence=0.65,
                    bounding_box=BoundingBox(x=px - 5, y=py - 5, width=10, height=10),
                    frame_context=frame_context,
                )
        except Exception as e:
            logger.error(
                "perception_completed",
                provider="moondream",
                target=target_description,
                success=False,
                error=str(e),
            )
            raise GroundingFailure(f"Moondream failed: {e}") from e

        logger.info(
            "perception_completed",
            provider="moondream",
            target=target_description,
            success=False,
            reason="no_detection_or_point",
        )
        return None


class GeminiBackend(GrounderBackend):
    """Backend for Gemini Flash visual grounding using Set-of-Mark overlays.

    P2-12 (D6, D8): adds a per-instance quota-exhaustion circuit breaker
    and a per-run response cache to (a) avoid burning more quota on a
    failed provider and (b) skip duplicate calls for identical targets
    within the same run. Quota exhaustion is now surfaced explicitly via
    ``is_quota_exhausted()`` so the report can call it out as a run
    limitation rather than a silent fallback to other perception paths.
    """

    # Class-level quota state — shared across instances within a single
    # worker process so the death of one GeminiBackend instance doesn't
    # let another immediately retry and burn more quota. Reset only on
    # ``reset_quota_state()`` (typically called between runs).
    _QUOTA_LOCK = asyncio.Lock()
    _QUOTA_EXHAUSTED: bool = False
    _QUOTA_EXHAUSTED_AT: str = ""
    _QUOTA_RESET_AFTER_SECONDS: float = 60.0  # cool-down before retrying
    _QUOTA_LAST_RESET_AT: float = 0.0  # monotonic time of last reset

    @classmethod
    def is_quota_exhausted(cls) -> bool:
        """Return True if the Gemini provider has hit a quota ceiling.

        When True, callers should treat the absence of Gemini grounding
        as a run limitation (not a silent fallback to another path).
        The reporting engine reads this flag and emits a
        ``gemini_quota_exhausted`` indicator in the report environment.
        """
        import time
        if not cls._QUOTA_EXHAUSTED:
            return False
        # Auto-reset after cool-down so a fresh run isn't permanently
        # blocked by a stale quota flag.
        if (time.monotonic() - cls._QUOTA_LAST_RESET_AT) > cls._QUOTA_RESET_AFTER_SECONDS:
            cls._QUOTA_EXHAUSTED = False
            cls._QUOTA_EXHAUSTED_AT = ""
            return False
        return True

    @classmethod
    def reset_quota_state(cls) -> None:
        """Clear the quota-exhausted flag (call between runs)."""
        import time
        cls._QUOTA_EXHAUSTED = False
        cls._QUOTA_EXHAUSTED_AT = ""
        cls._QUOTA_LAST_RESET_AT = time.monotonic()

    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is required")
        self.model = None
        self._has_sdk = False
        try:
            import google.generativeai as genai  # type: ignore[import-untyped]

            genai.configure(api_key=self.api_key, transport="rest")
            self._model_name = os.environ.get("GEMINI_MODEL", "gemini-3.8-flash")
            self.model = genai.GenerativeModel(self._model_name)
            self._has_sdk = True
        except ImportError:
            self._has_sdk = False

        # P2-12: per-instance response cache. Keyed by
        # (target_description, overlay_count). Avoids duplicate Gemini
        # calls when the agent re-grounds the same target across retries
        # without the page actually changing. Cache is process-local and
        # not cross-run (cleared on backend reconstruction).
        self._response_cache: dict[tuple[str, int], PerceptionCandidate | None] = {}
        self._cache_hits = 0
        self._cache_misses = 0

    def get_cache_stats(self) -> dict[str, int]:
        """Return per-instance cache statistics for diagnostics."""
        return {
            "cache_hits": self._cache_hits,
            "cache_misses": self._cache_misses,
            "cache_size": len(self._response_cache),
        }

    async def ground_element(
        self,
        screenshot_bytes: bytes,
        target_description: str,
        threshold: float = 0.8,
        frame_context: str | None = None,
        page: Page | None = None,
    ) -> PerceptionCandidate | None:
        # P2-12: short-circuit if the Gemini quota has been exhausted.
        # Returning None here lets the PerceptionRouter fall back to a
        # DOM-only path; the report will flag the quota exhaustion
        # explicitly so a reviewer doesn't mistake this for a silent
        # fallback that produced a passing result without vision.
        if GeminiBackend.is_quota_exhausted():
            logger.info(
                "gemini_quota_exhausted_short_circuit",
                target=target_description,
            )
            return None

        if not page:
            raise GroundingFailure("GeminiBackend requires page object for overlays.")

        # Gather candidate elements via JS
        boxes = await page.evaluate("""() => {
            return Array.from(document.querySelectorAll('button, a, input, select, textarea, [role="button"], [role="link"], [role="tab"], [role="menuitem"], .tabs2_tab, span.tab_caption_text, .tab_header, [data-original-title]'))
                .map((el, idx) => {
                    const rect = el.getBoundingClientRect();
                    return {id: idx + 1, x: rect.x, y: rect.y, width: rect.width, height: rect.height};
                })
                .filter(b => b.width > 0 && b.height > 0 && b.x >= 0 && b.y >= 0);
        }""")

        if not boxes:
            return None

        # P2-12: check the per-instance cache. The same target on the
        # same overlay set is highly likely to produce the same Gemini
        # response — skip the call when we've seen it before.
        cache_key = (target_description.lower().strip(), len(boxes))
        if cache_key in self._response_cache:
            self._cache_hits += 1
            logger.info(
                "gemini_cache_hit",
                target=target_description,
                overlay_count=len(boxes),
            )
            return self._response_cache[cache_key]
        self._cache_misses += 1

        from PIL import Image, ImageDraw

        img = Image.open(io.BytesIO(screenshot_bytes)).convert("RGB")
        draw = ImageDraw.Draw(img)

        # Draw overlays
        for b in boxes:
            x, y, w, h = b["x"], b["y"], b["width"], b["height"]
            draw.rectangle([x, y, x + w, y + h], outline="red", width=2)
            draw.rectangle([x, y, x + 22, y + 14], fill="red")
            draw.text((x + 2, y + 1), str(b["id"]), fill="white")

        overlay_bytes = io.BytesIO()
        img.save(overlay_bytes, format="PNG")
        overlay_bytes.seek(0)

        prompt = f"Identify the ID number of the UI element corresponding to '{target_description}'. Respond with ONLY the integer."

        logger.info(
            "perception_started",
            provider="gemini",
            task="ground_element",
            target=target_description,
            overlay_elements=len(boxes),
        )

        try:
            used_sdk = False
            if self._has_sdk and self.model:
                try:
                    annotated_img = Image.open(overlay_bytes)
                    import inspect
                    res = self.model.generate_content([prompt, annotated_img])
                    if inspect.isawaitable(res):
                        response = await res
                    else:
                        response = res
                    idx_str = response.text.strip()
                    used_sdk = True
                except Exception as sdk_err:
                    logger.warning("gemini_sdk_call_failed_using_rest", error=str(sdk_err))
                    used_sdk = False
            if not used_sdk:
                import base64
                import httpx

                img_b64 = base64.b64encode(overlay_bytes.getvalue()).decode("utf-8")
                payload = {
                    "contents": [
                        {
                            "parts": [
                                {"text": prompt},
                                {
                                    "inline_data": {
                                        "mime_type": "image/png",
                                        "data": img_b64,
                                    }
                                },
                            ]
                        }
                    ]
                }
                async with httpx.AsyncClient(timeout=30.0) as client:
                    model_name = getattr(self, "_model_name", os.environ.get("GEMINI_MODEL", "gemini-3.8-flash"))
                    resp = await client.post(
                        f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={self.api_key}",
                        json=payload,
                    )
                    # P2-12: detect quota exhaustion (HTTP 429) and trip
                    # the circuit breaker so subsequent calls short-circuit.
                    if resp.status_code == 429:
                        async with GeminiBackend._QUOTA_LOCK:
                            GeminiBackend._QUOTA_EXHAUSTED = True
                            from datetime import UTC, datetime
                            GeminiBackend._QUOTA_EXHAUSTED_AT = datetime.now(UTC).isoformat()
                        logger.warning(
                            "gemini_quota_exhausted",
                            status_code=429,
                            target=target_description,
                            message="Google API quota exhausted — Gemini grounding will be skipped until cool-down.",
                        )
                        # Cache the negative result so subsequent identical
                        # calls don't even enter the function body.
                        self._response_cache[cache_key] = None
                        return None
                    resp.raise_for_status()
                    data = resp.json()
                    idx_str = data["candidates"][0]["content"]["parts"][0]["text"].strip()
            m = re.search(r"\d+", idx_str)
            if not m:
                logger.info(
                    "perception_completed",
                    provider="gemini",
                    target=target_description,
                    success=False,
                    reason="no_id_in_response",
                )
                self._response_cache[cache_key] = None
                return None

            target_id = int(m.group())
            for b in boxes:
                if b["id"] == target_id:
                    candidate = PerceptionCandidate(
                        source="gemini_overlay",
                        target_description=target_description,
                        confidence=0.9,
                        bounding_box=BoundingBox(
                            x=int(b["x"]),
                            y=int(b["y"]),
                            width=int(b["width"]),
                            height=int(b["height"]),
                        ),
                        frame_context=frame_context,
                    )
                    logger.info(
                        "perception_completed",
                        provider="gemini",
                        target=target_description,
                        success=True,
                        matched_id=target_id,
                        x=int(b["x"]),
                        y=int(b["y"]),
                    )
                    self._response_cache[cache_key] = candidate
                    return candidate
        except Exception as e:
            error_str = str(e)
            # P2-12: detect quota-exhaustion in the SDK path too — the
            # Google SDK raises a ResourceExhausted exception whose message
            # contains "429" or "Resource has been exhausted".
            if "429" in error_str or "Resource has been exhausted" in error_str or "quota" in error_str.lower():
                async with GeminiBackend._QUOTA_LOCK:
                    GeminiBackend._QUOTA_EXHAUSTED = True
                    from datetime import UTC, datetime
                    GeminiBackend._QUOTA_EXHAUSTED_AT = datetime.now(UTC).isoformat()
                logger.warning(
                    "gemini_quota_exhausted",
                    target=target_description,
                    message="Google API quota exhausted — Gemini grounding will be skipped until cool-down.",
                    error=error_str[:200],
                )
                self._response_cache[cache_key] = None
                return None
            logger.error(
                "perception_completed",
                provider="gemini",
                target=target_description,
                success=False,
                error=error_str,
            )
            raise GroundingFailure(f"Gemini failed: {e}") from e

        self._response_cache[cache_key] = None
        return None


class PerceptionRouter(GrounderBackend):
    """Router that attempts Primary provider, and on failure tries Fallback."""

    def __init__(
        self,
        primary: GrounderBackend,
        fallback: GrounderBackend | None = None,
        local: GrounderBackend | None = None,
    ) -> None:
        self.primary = primary
        self.fallback = fallback
        self.local = local

    async def ground_element(
        self,
        screenshot_bytes: bytes,
        target_description: str,
        threshold: float = 0.8,
        frame_context: str | None = None,
        page: Page | None = None,
    ) -> PerceptionCandidate | None:
        logger.info("routing_grounding_request", target=target_description, provider="primary")
        try:
            res = await self.primary.ground_element(
                screenshot_bytes, target_description, threshold, frame_context, page
            )
            if res:
                logger.info("primary_grounding_success", target=target_description)
                return res
        except Exception as e:
            logger.warning(
                "primary_grounding_failed", error=str(e), fallback_available=bool(self.fallback)
            )

        if self.fallback:
            logger.info("routing_grounding_request", target=target_description, provider="fallback")
            try:
                res = await self.fallback.ground_element(
                    screenshot_bytes, target_description, threshold, frame_context, page
                )
                if res:
                    logger.info("fallback_grounding_success", target=target_description)
                    return res
            except Exception as e:
                logger.warning("fallback_grounding_failed", error=str(e))

        return None
