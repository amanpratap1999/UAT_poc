"""Reporting engine — generates professional QA reports from session memory.

Produces both HTML and Markdown reports with execution timelines,
validation summaries, defect lists, browser logs, and LLM-generated
executive summaries with root-cause hypotheses.
"""

from __future__ import annotations

import asyncio
import json
import os
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from agent.core.logging import get_logger
from agent.core.redaction import redact_string
from agent.core.types import Severity
from agent.domain.defect_scope import (
    VERIFIED_DEFECT_ERROR_TYPE,
    classify_step_failure,
)
from agent.domain.report import (
    AgentIssueReport,
    BrowserLogEntry,
    DefectReport,
    TestReport,
    TimelineEntry,
)
from agent.memory.session import SessionMemory

logger = get_logger(__name__)


def _step_text(step: Any) -> str:
    """Render a planned step (dict or TestStep) as readable text."""
    if isinstance(step, dict):
        at = step.get("action_type", "")
        target = step.get("target", "")
        value = step.get("value", "")
        expected = step.get("expected_outcome", "")
        text = f"{at} {target}".strip()
        if value:
            text += f" with '{value}'"
        if expected:
            text += f" | {expected}"
        return text
    return str(step)


def _stringify_cell(value: Any) -> str:
    """Render a cell value (dict/list/other) as compact text for XLSX."""
    if isinstance(value, dict):
        try:
            import json as _json

            return _json.dumps(value, default=str)
        except Exception:
            return str(value)
    if isinstance(value, (list, tuple)):
        return "; ".join(str(v) for v in value)
    return str(value)


class ReportingEngine:
    """Generates comprehensive QA test reports from session memory.

    Produces structured reports with:
    - Execution timeline with screenshots
    - Validation summary (pass/fail breakdown)
    - Defect reports with evidence
    - Browser and console logs
    - Executive summary and recommendations
    """

    def __init__(self, output_dir: Path = Path("reports")) -> None:
        self._output_dir = output_dir
        self._output_dir.mkdir(parents=True, exist_ok=True)

    async def generate_report(
        self,
        memory: SessionMemory,
        summary_data: dict[str, Any] | None = None,
    ) -> TestReport:
        """Generate a complete QA report from session memory.

        Args:
            memory: The session memory containing all execution data.
            summary_data: Optional LLM-generated summary data.

        Returns:
            A fully populated TestReport.
        """
        logger.info("generating_report", session_id=memory.session_id)

        report_id = f"RPT-{uuid.uuid4().hex[:8].upper()}"
        now = datetime.now(UTC)

        # Build timeline from memory
        timeline = self._build_timeline(memory)

        # Compute validation stats
        passed = sum(1 for v in memory.completed_validations if v.overall_passed)
        failed = sum(1 for v in memory.completed_validations if not v.overall_passed)
        total = len(memory.completed_validations)

        # Build validation details
        validation_details = [
            {
                "action": v.action_description,
                "passed": v.overall_passed,
                "checks": len(v.checks),
                "failed_checks": [c.check_name for c in v.failed_checks],
            }
            for v in memory.completed_validations
        ]

        # Identify application defects and agent issues (scope-classified)
        (
            defects,
            agent_issues,
            agent_issue_count,
            application_mismatch_count,
        ) = self._identify_defects(memory)

        # Build browser logs
        browser_logs = self._build_browser_logs(memory)

        # Collect all screenshots
        screenshots = [entry.screenshot_path for entry in memory.timeline if entry.screenshot_path]

        # Step evidence
        step_evidence: list[dict[str, Any]] = []
        for step in memory.completed_steps:
            screenshot_path = getattr(step.result, "screenshot_path", None)
            ev: dict[str, Any] = {
                "step_index": step.step_index,
                "action": step.action.action_type if hasattr(step.action, "action_type") else str(step.action),
                "target": getattr(step.action, "target", ""),
                "result": "success" if (hasattr(step.result, "success") and step.result.success) else "failed",
                "screenshot_path": screenshot_path,
            }
            if screenshot_path and screenshot_path not in screenshots:
                screenshots.append(screenshot_path)
            if hasattr(step.result, "details") and isinstance(step.result.details, dict):
                if "perception" in step.result.details:
                    ev["perception"] = step.result.details["perception"]
            step_evidence.append(ev)

        # Determine overall status.
        #
        # Strict QA status semantics:
        # - "precondition_failed": Required initial conditions (e.g. record number or initial state) were not met before mutation.
        # - "failed": QA verdict is FAIL because application defects exist, acceptance criteria failed, or validation checks failed.
        # - "blocked": Engine was blocked from starting or executing.
        # - "error": Engine encountered an internal execution or runtime failure.
        # - "passed": ONLY when all executed validations passed (failed == 0, passed > 0), no application defects exist, and no preconditions failed.
        has_application_defects = len(defects) > 0

        precondition_failure = (
            getattr(memory, "precondition_failed", False)
            or any(
                getattr(v, "precondition_failed", False)
                for v in memory.completed_validations
            )
            or any(
                getattr(getattr(step, "validation", None), "precondition_failed", False)
                for step in memory.completed_steps
            )
        )

        if getattr(memory, "cleanup_status", None) == "cleanup_failed":
            status = "cleanup_failed"
        elif precondition_failure:
            status = "precondition_failed"
            # Hard QA rule: An application defect can ONLY exist if preconditions
            # passed and the action was executed. Precondition failures yield 0 defects.
            defects = []
        elif memory.total_actions_executed == 0 and len(memory.completed_steps) == 0:
            status = "error" if memory.total_failures > 0 else "blocked"
        elif has_application_defects:
            status = "failed" if passed == 0 else "partial"
        elif failed > 0:
            status = "failed" if passed == 0 else "partial"
        elif memory.total_failures > 0:
            status = "failed"
        elif passed > 0:
            status = "passed"
        else:
            status = "blocked"

        # Calculate duration
        duration = (now - memory.started_at).total_seconds()

        # Augment step_evidence with canonical plan steps if present
        if memory.plan and memory.plan.steps:
            existing_indices = {se.get("step_index") for se in step_evidence if isinstance(se, dict)}
            for s in memory.plan.steps:
                if s.step_index not in existing_indices:
                    step_evidence.append(
                        {
                            "step_index": s.step_index,
                            "action": "plan_step",
                            "target": s.description,
                            "result": s.status.value if hasattr(s.status, "value") else str(s.status),
                            "error": s.error,
                            "observed_values": s.observed_values,
                            "expected_values": s.expected_values,
                        }
                    )

        report = TestReport(
            report_id=report_id,
            goal=memory.goal,
            test_case=memory.test_case_data or None,
            status=status,
            started_at=memory.started_at,
            completed_at=now,
            duration_seconds=duration,
            timeline=timeline,
            total_validations=total,
            passed_validations=passed,
            failed_validations=failed,
            validation_details=validation_details,
            defects=defects,
            agent_issues=agent_issues,
            browser_logs=browser_logs,
            console_errors=list(getattr(memory, "console_errors", [])) + [
                f.error_message
                for f in memory.failures
                if "js" in f.error_type.lower() or "console" in f.error_type.lower()
            ],
            screenshots=screenshots,
            step_evidence=step_evidence,
            environment={
                "session_id": memory.session_id,
                "url": memory.current_url,
                "persona": getattr(memory, "persona", "") or "",
                "story_id": (memory.test_case_data or {}).get("story_id") or "",
            },
        )

        # Apply LLM-generated summary if available
        if summary_data:
            report.summary = summary_data.get("summary", "")
            report.recommendations = summary_data.get("recommendations", [])
            # Apply root cause hypotheses to defects
            for hypothesis in summary_data.get("root_cause_hypotheses", []):
                defect_id = hypothesis.get("defect_id", "")
                for defect in report.defects:
                    if defect.defect_id == defect_id:
                        defect.root_cause_hypothesis = hypothesis.get("hypothesis", "")

        # INC-UAT-12 (Major): collect requirement IDs from the plan steps
        if memory.plan and memory.plan.steps:
            report.requirement_ids_covered = list(set(
                s.requirement_id for s in memory.plan.steps
                if getattr(s, "requirement_id", None)
            ))

        # P0-03 (D1, D6 — AC mapping): build a structured per-criterion
        # result list. We REQUIRE real acceptance-criterion IDs from the
        # imported test case; never infer the requirement count from plan
        # steps when the AC list is empty (lines 279–283 of the prior
        # implementation did exactly that, which silently manufactured
        # coverage from execution length and produced false-positive UAT
        # sign-offs). With this change:
        #   • AC list empty  → authoritative_total = 0 → coverage reports
        #     as 0% and the run is marked blocked (NOT a pass).
        #   • AC list present but a criterion has no observed evidence →
        #     status = "blocked", reported as such, not as coverage.
        #   • AC matched → status = pass / fail with expected+observed.
        tc_data = memory.test_case_data or {}
        raw_ac_list = tc_data.get("acceptance_criteria", []) or []
        if not isinstance(raw_ac_list, list):
            raw_ac_list = []
        # C1: Exclude plan-invented ACs (tagged source="plan") from authoritative ACs
        authoritative_ac_list = [
            ac for ac in raw_ac_list
            if not (isinstance(ac, dict) and ac.get("source") == "plan")
        ]
        normalized_ac: list[dict[str, Any]] = []
        for idx, ac in enumerate(authoritative_ac_list):
            if isinstance(ac, dict):
                normalized_ac.append({
                    "criterion_id": str(ac.get("id") or ac.get("criterion_id") or f"AC-{idx + 1:03d}"),
                    "expected": str(ac.get("expected") or ac.get("expected_value") or ac.get("description") or ""),
                    "field": str(ac.get("field") or ac.get("field_path") or ""),
                    "operator": str(ac.get("operator") or "equals"),
                    "description": str(ac.get("description") or ""),
                })
            else:
                normalized_ac.append({
                    "criterion_id": f"AC-{idx + 1:03d}",
                    "expected": str(ac),
                    "field": "",
                    "operator": "equals",
                    "description": str(ac),
                })
        report.acceptance_criteria_results = self._map_acceptance_criteria(
            normalized_ac, memory
        )

        # INC-UAT-15 (Minor): evaluate exit criteria and embed in the report
        # P0-03 fix (reviewer feedback): use an AUTHORITATIVE total
        # requirement count from the test case data — NOT from
        # requirement_ids_covered (which would always make coverage 100%)
        # and NOT from plan steps when the AC list is empty (lines 279–283
        # of the prior implementation did that and inflated coverage).
        try:
            from agent.reporting.exit_criteria import IncidentExitCriteriaEngine
            exit_engine = IncidentExitCriteriaEngine()
            major_defects = sum(1 for d in defects if getattr(d, "severity", "").lower() in ("critical", "high", "major"))
            minor_defects = sum(1 for d in defects if getattr(d, "severity", "").lower() in ("minor", "low"))
            unverified = sum(1 for v in memory.completed_validations if not v.overall_passed and not v.failed_checks)
            # Authoritative total: from test_case_data's acceptance_criteria
            # list ONLY. When the list is empty the run honestly reports
            # coverage as 0% (which the exit-criteria engine treats as a
            # coverage-gap → BLOCKED), rather than fabricating a denominator
            # from plan-step count.
            authoritative_total = len(normalized_ac)
            covered_with_evidence = sum(
                1
                for r in (report.acceptance_criteria_results or [])
                if r.get("status") == "pass" and bool(str(r.get("observed", "")).strip())
            )
            infra_error_count = sum(
                1
                for issue in (report.agent_issues or [])
                if getattr(issue, "category", "") in ("runtime", "execution")
            )
            exit_result = exit_engine.evaluate(
                requirements_total=authoritative_total,
                requirements_covered=covered_with_evidence,
                open_major_defects=major_defects,
                open_minor_defects=minor_defects,
                unverified_items=unverified,
                infra_errors=infra_error_count,
                total_runs=1 if (report.total_validations == 0 and infra_error_count > 0) else max(1, report.total_validations),
            )
            # Enforce mandatory exit criteria invariants:
            # 1. report.status != "passed" -> exit_criteria.verdict != "PASS"
            # 2. failed_validations > 0 -> exit_criteria.verdict != "PASS"
            # 3. passed_validations < total_validations -> exit_criteria.verdict != "PASS"
            # 4. requirements_total == 0 -> must NOT automatically result in PASS
            if (
                report.status != "passed"
                or report.failed_validations > 0
                or report.passed_validations < report.total_validations
                or authoritative_total == 0
            ):
                if exit_result.verdict == "PASS":
                    if report.status == "failed" or report.failed_validations > 0:
                        exit_result.verdict = "FAIL"
                        exit_result.reason = (
                            f"Report status is '{report.status}' with "
                            f"{report.failed_validations} failed validation(s)."
                        )
                    elif authoritative_total == 0:
                        exit_result.verdict = "INCONCLUSIVE"
                        exit_result.reason = (
                            "Zero authoritative requirements configured; sign-off verdict cannot be PASS."
                        )
                    else:
                        exit_result.verdict = "CONDITIONAL_PASS"
                        exit_result.reason = (
                            f"Run status is '{report.status}' "
                            f"({report.passed_validations}/{report.total_validations} validations passed)."
                        )

            report.exit_criteria = exit_result.to_dict()
            # The top-level report status is the result clients and runners
            # commonly consume. Never leave it as PASSED when the stricter
            # Incident sign-off engine found insufficient coverage or a
            # blocker; doing so creates a false-positive UAT sign-off.
            # C1: Drop authoritative_total > 0 guard so INCONCLUSIVE always downgrades status
            if report.status in {"passed", "partial"}:
                exit_status = {
                    "FAIL": "failed",
                    "BLOCKED": "blocked",
                    "INCONCLUSIVE": "blocked",
                    "INFRA_ERROR": "error",
                    "CONDITIONAL_PASS": "partial",
                }.get(exit_result.verdict)
                if exit_status:
                    logger.warning(
                        "report_status_downgraded_by_exit_criteria",
                        report_id=report.report_id,
                        previous_status=report.status,
                        exit_verdict=exit_result.verdict,
                        new_status=exit_status,
                    )
                    report.status = exit_status
            logger.info(
                "exit_criteria_evaluated",
                verdict=exit_result.verdict,
                reason=exit_result.reason,
            )
        except Exception as e:
            logger.warning("exit_criteria_evaluation_failed", error=str(e))

        # P3-03: store reproducibility metadata with every run
        try:
            import subprocess
            repo_commit = subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
                stderr=subprocess.DEVNULL, timeout=5,
            ).decode().strip()
        except Exception:
            repo_commit = "unknown"
        report.reproducibility = {
            "repo_commit": repo_commit,
            "config_version": "1.0",
            "llm_provider": getattr(getattr(memory, "_settings", None) or type("s", (), {"llm": type("l", (), {"provider": "unknown", "model": "unknown"})()}), "llm", None),
            "persona": getattr(memory, "persona", "") or "",
            "tenant_id": getattr(memory, "tenant_id", "") or "",
            "session_id": memory.session_id,
            "generated_at": datetime.now(UTC).isoformat(),
        }

        # P1-08 (D7): copy the retest packages from session memory onto the
        # report so a reviewer can see both the original finding AND the
        # retest outcome. A fix must not erase the original finding.
        report.retest_results = list(getattr(memory, "retest_packages", []) or [])

        # P2-10 (D6, D10): extend report output with run ID, timestamp,
        # persona, criteria mapping, screenshots, errors, and final status
        # so a reviewer can trace every reported result to its run and
        # supporting artifact. These are simple additions to the existing
        # TestReport fields (no new model fields required) — we just
        # populate them explicitly so the JSON / Markdown renderers always
        # emit them.
        if not report.environment:
            report.environment = {}
        report.environment.update({
            "run_id": memory.session_id,
            "persona": getattr(memory, "persona", "") or "",
            "tenant_id": getattr(memory, "tenant_id", "") or "",
            "generated_at": datetime.now(UTC).isoformat(),
            "final_status": report.status,
        })
        # P2-12 (D6, D8): surface Gemini quota exhaustion explicitly so
        # a reviewer sees it as a run limitation rather than mistaking
        # a silent fallback to other perception paths for a passing
        # result. Also surfaces the per-instance cache stats so the cost
        # of duplicate Gemini calls within the run is visible.
        try:
            from agent.perception.backends import GeminiBackend
            report.environment["gemini_quota_exhausted"] = bool(
                GeminiBackend.is_quota_exhausted()
            )
            # The exhausted_at timestamp lives on the class — surface it
            # so a reviewer can correlate with provider rate-limit windows.
            if GeminiBackend._QUOTA_EXHAUSTED_AT:
                report.environment["gemini_quota_exhausted_at"] = (
                    GeminiBackend._QUOTA_EXHAUSTED_AT
                )
            # Reset the quota flag at the end of the run so the next run
            # starts fresh (otherwise a single quota hit would block all
            # subsequent runs until the cool-down elapses).
            GeminiBackend.reset_quota_state()
        except Exception as quota_err:
            logger.warning("gemini_quota_status_check_failed", error=str(quota_err))
        # Collect screenshot paths from all completed steps so reviewers
        # can trace every reported result to its supporting artifact.
        step_screenshots: list[str] = []
        for step in memory.completed_steps:
            if step.result and step.result.screenshot_path:
                step_screenshots.append(step.result.screenshot_path)
            if step.observation_after and getattr(step.observation_after, "screenshot_path", None):
                step_screenshots.append(step.observation_after.screenshot_path)
        if step_screenshots and not report.screenshots:
            report.screenshots = step_screenshots
        # Console errors aggregated from browser telemetry
        if not report.console_errors and getattr(memory, "console_errors", []):
            report.console_errors = list(memory.console_errors)

        # P9-LAYA: record per-action source telemetry so a reviewer can see
        # whether each action came from LAYA, Gemini, or a deterministic
        # rule, plus confidence, inference latency, fallback reason, and
        # model version. Also measures total cost and latency per run.
        action_source_telemetry = self._build_action_source_telemetry(memory)
        if not report.environment:
            report.environment = {}
        report.environment["action_source_telemetry"] = action_source_telemetry

        logger.info(
            "report_generated",
            report_id=report_id,
            status=report.status,
            defects=len(defects),
        )
        return report

    def _build_action_source_telemetry(self, memory: SessionMemory) -> dict[str, Any]:
        """P9-LAYA: build per-action source telemetry for the report.

        Walks ``memory.completed_steps`` and extracts the ``action_source``
        metadata from each step's action. Returns a summary dict with:
          - ``per_action``: list of {step_index, source, confidence,
            latency_ms, fallback_reason, model_version}
          - ``summary``: {laya_count, gemini_count, heuristic_count,
            laya_avg_confidence, laya_avg_latency_ms, total_inference_ms}
        """
        per_action: list[dict[str, Any]] = []
        source_counts: dict[str, int] = {"laya": 0, "gemini": 0, "heuristic": 0, "unknown": 0}
        laya_confidences: list[float] = []
        laya_latencies: list[float] = []
        laya_model_versions: set[str] = set()
        laya_fallback_reasons: dict[str, int] = {}

        for step in memory.completed_steps:
            action = getattr(step, "action", None)
            if action is None:
                continue
            metadata = getattr(action, "metadata", {}) or {}
            source = str(metadata.get("action_source", "unknown"))
            confidence = float(metadata.get("laya_confidence", 0.0) or 0.0)
            latency_ms = float(metadata.get("laya_inference_latency_ms", 0.0) or 0.0)
            fallback_reason = str(metadata.get("laya_fallback_reason", "") or "")
            model_version = str(metadata.get("laya_model_version", "") or "")

            # Normalize source
            if source not in source_counts:
                source_counts["unknown"] = source_counts.get("unknown", 0) + 1
            else:
                source_counts[source] = source_counts.get(source, 0) + 1

            if source == "laya":
                laya_confidences.append(confidence)
                laya_latencies.append(latency_ms)
                if model_version:
                    laya_model_versions.add(model_version)
                if fallback_reason:
                    laya_fallback_reasons[fallback_reason] = (
                        laya_fallback_reasons.get(fallback_reason, 0) + 1
                    )

            per_action.append({
                "step_index": getattr(step, "step_index", -1),
                "source": source,
                "confidence": round(confidence, 4),
                "inference_latency_ms": round(latency_ms, 2),
                "fallback_reason": fallback_reason,
                "model_version": model_version,
                "action_type": str(getattr(action, "action_type", "")),
                "target": str(getattr(action, "target", ""))[:80],
            })

        # Compute LAYA averages
        laya_avg_confidence = (
            sum(laya_confidences) / len(laya_confidences)
            if laya_confidences else 0.0
        )
        laya_avg_latency = (
            sum(laya_latencies) / len(laya_latencies)
            if laya_latencies else 0.0
        )
        total_inference_ms = sum(laya_latencies)

        # Total run cost estimation (very rough — operator should refine)
        # Gemini planning calls + LAYA inference calls
        gemini_calls = getattr(memory, "planner_calls", 0) or 0
        laya_calls = len(laya_confidences)
        moondream_calls = getattr(memory, "moondream_calls", 0) or 0
        gemini_vision_calls = getattr(memory, "gemini_calls", 0) or 0
        verification_calls = getattr(memory, "verification_calls", 0) or 0
        timeline_duration_ms = sum(
            max(0.0, float(getattr(entry, "duration_ms", 0.0) or 0.0))
            for entry in memory.timeline
        )

        return {
            "per_action": per_action,
            "summary": {
                "source_counts": source_counts,
                "laya_count": source_counts.get("laya", 0),
                "gemini_count": source_counts.get("gemini", 0),
                "heuristic_count": source_counts.get("heuristic", 0),
                "laya_avg_confidence": round(laya_avg_confidence, 4),
                "laya_avg_latency_ms": round(laya_avg_latency, 2),
                "laya_total_inference_ms": round(total_inference_ms, 2),
                "laya_model_versions": sorted(laya_model_versions),
                "laya_fallback_reasons": laya_fallback_reasons,
                "total_model_calls": {
                    "gemini_planning": gemini_calls,
                    "laya_action": laya_calls,
                    "moondream_vision": moondream_calls,
                    "gemini_vision": gemini_vision_calls,
                    "verification": verification_calls,
                },
                "total_duration_seconds": round(timeline_duration_ms / 1000.0, 3),
                # Provider pricing/token usage is not consistently exposed
                # by all configured clients. Report call counts and measured
                # LAYA time, but do not invent a currency amount.
                "estimated_cost_usd": None,
                "cost_estimate_note": (
                    "Unavailable: provider token usage and pricing were not "
                    "captured for every model call."
                ),
            },
        }

    def _build_timeline(self, memory: SessionMemory) -> list[TimelineEntry]:
        """Build the execution timeline from session memory."""
        return list(memory.timeline)

    def _identify_defects(
        self, memory: SessionMemory
    ) -> tuple[list[DefectReport], list[AgentIssueReport], int, int]:
        """Identify APPLICATION defects and AGENT issues from session evidence.

        Preserves the conceptual separation between application defects and
        agent/execution issues (see ``agent.domain.defect_scope``):

        - **Application defect** — the step's interaction executed and the
          failed checks are about the application's observed behavior, with
          either an investigation verdict confirming a genuine defect, or no
          verdict but application-behavior evidence (routed for review, not
          silently discarded).
        - **Agent issue** — the engine could not perform/observe/verify:
          failed ActionResult, agent-capability checks (action_execution,
          page_responded, behavioral_verification), or runtime errors. Never
          counted as a defect, never discarded — preserved in agent_issues.

        Investigation verdicts (``memory.defect_verdicts``, hypothesis-keyed)
        supersede raw validation failures: confirmed defects are counted once;
        cleared mismatches (false-positive customizations) are withdrawn.

        Returns:
            (defects, agent_issues, agent_issue_count, application_mismatch_count)
        """  # noqa: D401
        defects: list[DefectReport] = []
        agent_issues: list[AgentIssueReport] = []
        application_mismatch_count = 0

        # Authoritative investigation verdicts, keyed by step index (the
        # cognitive loop records verdicts with the completed step's index).
        cleared_steps: set[int] = {
            v.step_index for v in memory.defect_verdicts if not v.is_defect
        }

        defect_counter = 0
        issue_counter = 0
        counted_steps: set[int] = set()

        for step in memory.completed_steps:
            if not (step.validation and not step.validation.overall_passed):
                continue

            scope = classify_step_failure(step.result, step.validation)

            if scope == "precondition":
                # Initial record/environment state did not meet test prerequisites.
                issue_counter += 1
                failed_checks = step.validation.failed_checks
                check_names = ", ".join(c.check_name for c in failed_checks) or "Precondition"
                agent_issues.append(
                    AgentIssueReport(
                        issue_id=f"PRE-{issue_counter:03d}",
                        title=f"Precondition check failed ({check_names})",
                        description=(
                            f"Step {step.step_index}: initial test precondition was not met. "
                            f"{'; '.join(c.error_message or c.actual for c in failed_checks)}. "
                            f"This is a test precondition failure, not an application defect."
                        ),
                        category="precondition_failed",
                        related_step_index=step.step_index,
                        error_type="PreconditionFailedError",
                    )
                )
                continue

            if scope == "agent":
                # The engine could not perform/observe/verify — diagnostic only.
                issue_counter += 1
                failed_checks = step.validation.failed_checks
                check_names = ", ".join(c.check_name for c in failed_checks) or "unknown"
                error_type = getattr(step.result, "error_type", None) or "AgentSideFailure"
                agent_issues.append(
                    AgentIssueReport(
                        issue_id=f"AGI-{issue_counter:03d}",
                        title=f"Agent-side validation failure ({check_names})",
                        description=(
                            f"Step {step.step_index}: the QA agent could not "
                            f"perform, observe, or verify the interaction "
                            f"({error_type}: {getattr(step.result, 'error', None) or 'no error recorded'}). "
                            f"This is an agent/execution issue, not an application defect."
                        ),
                        category=self._categorize_issue(error_type, check_names),
                        related_step_index=step.step_index,
                        error_type=error_type,
                    )
                )
                continue

            if scope is None:
                continue

            # Application-scope mismatch.
            application_mismatch_count += 1

            # Investigation verdict supersedes raw validation failure: a
            # cleared verdict (false-positive customization / learned
            # behavior) withdraws the defect for this step.
            if step.step_index in cleared_steps:
                continue

            failed_checks = step.validation.failed_checks
            repro_steps = [
                f"Step {s.step_index}: {s.action.action_type} on '{s.action.target}'"
                + (f" with value '{s.action.value}'" if getattr(s.action, "value", None) else "")
                for s in memory.completed_steps
                if s.step_index <= step.step_index and getattr(s, "action", None)
            ]
            evidence: list[str] = []
            if step.result and step.result.screenshot_path:
                evidence.append(step.result.screenshot_path)
            if step.observation_after and getattr(step.observation_after, "screenshot_path", None):
                if step.observation_after.screenshot_path not in evidence:
                    evidence.append(step.observation_after.screenshot_path)

            seen_signatures: set[tuple[str, str, str]] = set()
            for chk in failed_checks:
                sig = (chk.check_name, str(chk.expected), str(chk.actual))
                if sig in seen_signatures:
                    continue
                seen_signatures.add(sig)
                defect_counter += 1
                defects.append(
                    DefectReport(
                        defect_id=f"DEF-{defect_counter:03d}",
                        severity=self._assess_severity([chk]),
                        title=f"Validation failure: {chk.check_name}",
                        description=f"{chk.check_name}: expected={chk.expected}, actual={chk.actual}",
                        steps_to_reproduce=list(repro_steps),
                        expected_behavior=str(chk.expected),
                        actual_behavior=str(chk.actual),
                        evidence=list(evidence),
                        related_step_index=step.step_index,
                    )
                )
            counted_steps.add(step.step_index)

        # Investigated mismatches at steps not covered above (e.g. the verdict
        # exists but the corresponding validation record is agent-scope or
        # absent): investigation-confirmed defects are counted here, once.
        for verdict in memory.defect_verdicts:
            if not verdict.is_defect:
                continue
            if verdict.step_index in counted_steps:
                continue
            defect_counter += 1
            defects.append(
                DefectReport(
                    defect_id=f"DEF-{defect_counter:03d}",
                    severity=Severity.HIGH,
                    title="Investigated application defect",
                    description=(
                        f"{verdict.reasoning or 'Investigation confirmed a defect'}"
                        + (f" (hypothesis {verdict.hypothesis_id})" if verdict.hypothesis_id else "")
                    ),
                    actual_behavior=verdict.reasoning,
                    related_step_index=verdict.step_index,
                )
            )
            counted_steps.add(verdict.step_index)

        # Runtime/planning/browser failures without a verdict — agent issues,
        # never defects. InvestigationVerifiedDefect failures are covered by
        # the verdict loop above (verdicts are the authority); a stale
        # failure without a verdict is treated as an agent-side record to
        # guarantee it can never silently inflate the defect count.
        for failure in memory.failures:
            if failure.error_type == VERIFIED_DEFECT_ERROR_TYPE:
                continue
            issue_counter += 1
            agent_issues.append(
                AgentIssueReport(
                    issue_id=f"AGI-{issue_counter:03d}",
                    title=f"Agent failure: {failure.error_type}",
                    description=failure.error_message,
                    category=self._categorize_issue(failure.error_type, ""),
                    related_step_index=failure.step_index,
                    error_type=failure.error_type,
                )
            )

        return defects, agent_issues, len(agent_issues), application_mismatch_count

    def _map_acceptance_criteria(
        self,
        criteria: list[dict[str, Any]],
        memory: SessionMemory,
    ) -> list[dict[str, Any]]:
        """P0-03 (D1, D6): map each acceptance criterion to its observed result.

        Each criterion is resolved against ``memory.completed_steps``:
        - If a step's expected_values or observed_values reference the
          criterion's field, the criterion's status is ``pass`` or ``fail``
          based on the validation result.
        - If no step touched the criterion's field, the status is
          ``blocked`` — explicitly NOT treated as coverage.
        - Criteria whose expected value is empty (no contract) are
          ``not_scored`` rather than silently passed.

        Returns a list of dicts with keys: criterion_id, expected, observed,
        field, operator, status, evidence_refs, related_step_index.
        """
        results: list[dict[str, Any]] = []
        # Index completed-step observed_values by field name for quick lookup
        field_observations: dict[str, list[tuple[int, str, Any, bool]]] = {}
        for step in memory.completed_steps:
            if not step.validation:
                continue
            observed_values = (
                step.observation_after.observed_values
                if step.observation_after and hasattr(step.observation_after, "observed_values")
                else None
            )
            if not observed_values:
                # Fall back to ActionResult.details["observed_values"]
                if step.result and isinstance(step.result.details, dict):
                    observed_values = step.result.details.get("observed_values")
            if not isinstance(observed_values, dict):
                continue
            for field_name, value in observed_values.items():
                field_observations.setdefault(str(field_name).lower(), []).append(
                    (step.step_index, str(value), value, bool(step.validation.overall_passed))
                )

        # Also index the final_assertions evaluations from SessionMemory
        # (memory.completed_validations carries the canonical checks; their
        # `checks` list has check_name like "field_update" / "state_match"
        # with `expected` and `actual` fields).
        for validation in memory.completed_validations:
            for check in validation.checks:
                check_name = (getattr(check, "check_name", "") or "").lower()
                # Only consider field-level checks
                if "field" in check_name or "state" in check_name or "priority" in check_name:
                    field_label = ""
                    expected = getattr(check, "expected", "")
                    actual = getattr(check, "actual", "")
                    # Try to extract the field name from the check description
                    description = getattr(check, "description", "") or ""
                    if "state" in description.lower():
                        field_label = "state"
                    elif "priority" in description.lower():
                        field_label = "priority"
                    elif description:
                        # Use the first word of the description as a heuristic
                        field_label = description.lower().split()[0] if description.split() else ""
                    if field_label:
                        field_observations.setdefault(field_label.lower(), []).append(
                            (
                                getattr(check, "step_index", -1) if hasattr(check, "step_index") else -1,
                                str(actual),
                                actual,
                                bool(getattr(check, "passed", False)),
                            )
                        )

        for ac in criteria:
            criterion_id = ac["criterion_id"]
            expected = ac["expected"]
            field = ac["field"]
            operator = ac["operator"]
            description = ac.get("description", "")

            observed_hits = field_observations.get(field.lower(), []) if field else []

            if not expected.strip() and not field.strip():
                # No contract → do not silently pass
                results.append({
                    "criterion_id": criterion_id,
                    "expected": expected,
                    "observed": "",
                    "field": field,
                    "operator": operator,
                    "status": "not_scored",
                    "reason": "criterion has no expected value or field — cannot score",
                    "evidence_refs": [],
                    "related_step_index": None,
                })
                continue

            if not observed_hits:
                # Criterion exists but no step touched the field → blocked
                results.append({
                    "criterion_id": criterion_id,
                    "expected": expected,
                    "observed": "",
                    "field": field,
                    "operator": operator,
                    "status": "blocked",
                    "reason": (
                        f"no executed step observed the field '{field}' required by this criterion"
                    ),
                    "evidence_refs": [],
                    "related_step_index": None,
                })
                continue

            # Pick the most recent observation for this field
            step_index, observed_str, observed_val, step_passed = observed_hits[-1]

            # Evaluate operator
            ok = False
            try:
                if operator == "equals":
                    ok = str(observed_val).strip().casefold() == str(expected).strip().casefold()
                elif operator == "not_equals":
                    ok = str(observed_val).strip().casefold() != str(expected).strip().casefold()
                elif operator == "contains":
                    ok = str(expected).strip().casefold() in str(observed_val).strip().casefold()
                elif operator == "not_empty":
                    ok = bool(str(observed_val).strip())
                elif operator == "is_empty":
                    ok = not str(observed_val).strip()
                elif operator == "state_matches":
                    # State-name tolerant comparison: "2" ↔ "In Progress"
                    state_label_map = {
                        "1": "new", "2": "in progress", "3": "on hold",
                        "6": "resolved", "7": "closed", "8": "canceled",
                    }
                    obs_norm = str(observed_val).strip().casefold()
                    exp_norm = str(expected).strip().casefold()
                    obs_label = state_label_map.get(obs_norm, obs_norm)
                    exp_label = state_label_map.get(exp_norm, exp_norm)
                    ok = obs_norm == exp_norm or obs_label == exp_label
                else:
                    ok = step_passed  # fall back to the step's overall verdict
            except Exception:
                ok = False

            evidence_refs: list[str] = []
            matching_step = next(
                (s for s in memory.completed_steps if s.step_index == step_index),
                None,
            )
            if matching_step:
                if matching_step.result and matching_step.result.screenshot_path:
                    evidence_refs.append(matching_step.result.screenshot_path)
                if matching_step.observation_after and getattr(
                    matching_step.observation_after, "screenshot_path", None
                ):
                    evidence_refs.append(matching_step.observation_after.screenshot_path)

            results.append({
                "criterion_id": criterion_id,
                "expected": expected,
                "observed": observed_str,
                "field": field,
                "operator": operator,
                "status": "pass" if ok else "fail",
                "reason": (
                    f"{field} {operator} {expected!r}: observed {observed_str!r}"
                ),
                "evidence_refs": evidence_refs,
                "related_step_index": step_index,
            })

        return results

    def _categorize_issue(self, error_type: str, check_names: str) -> str:
        """Categorize an agent issue for diagnostics."""
        token = (error_type or "").lower()
        checks = (check_names or "").lower()
        if any(
            k in token
            for k in ("grounding", "perception", "moondream", "gemini", "vision")
        ) or any(k in checks for k in ("perception", "grounding")):
            return "perception"
        if any(k in token for k in ("verification", "verifier")) or "behavioral" in checks:
            return "verification"
        if any(k in token for k in ("planner", "planning", "hypothesis", "llm")):
            return "planning"
        if any(
            k in token
            for k in ("browser", "playwright", "page", "navigation", "protocol")
        ):
            return "runtime"
        return "execution"

    def _assess_severity(self, failed_checks: list) -> Severity:  # type: ignore[type-arg]
        """Assess defect severity based on the types of failed checks (C25)."""
        critical_checks = {"action_execution", "state_change", "page_navigation", "semantic_context", "acl_violation"}
        high_checks = {"field_update", "no_js_errors", "no_new_js_errors", "no_new_errors", "no_network_errors", "update_response"}

        check_names = {c.check_name for c in failed_checks}

        if check_names & critical_checks:
            return Severity.CRITICAL
        if check_names & high_checks:
            return Severity.HIGH
        return Severity.MEDIUM

    def _build_browser_logs(self, memory: SessionMemory) -> list[BrowserLogEntry]:
        """Compile browser log entries from browser telemetry, errors, and failure records."""
        logs: list[BrowserLogEntry] = []

        # 1. Playwright console logs
        for entry in getattr(memory, "browser_logs", []):
            lvl = entry.get("level", "info")
            msg = entry.get("message", "")
            if msg:
                logs.append(
                    BrowserLogEntry(
                        level=lvl,
                        message=msg,
                        source="browser",
                    )
                )

        # 2. Page errors
        for err in getattr(memory, "console_errors", []):
            logs.append(
                BrowserLogEntry(
                    level="error",
                    message=f"[PageError] {err}",
                    source="browser",
                )
            )

        # 3. Network errors
        for net_err in getattr(memory, "network_errors", []):
            logs.append(
                BrowserLogEntry(
                    level="warning",
                    message=f"[NetworkError] {net_err}",
                    source="network",
                )
            )

        # 4. Memory failures
        for failure in memory.failures:
            logs.append(
                BrowserLogEntry(
                    level="error",
                    message=f"[{failure.error_type}] {failure.error_message}",
                    source="agent",
                )
            )
        return logs

    async def render_markdown(self, report: TestReport) -> str:
        """Render the report as a Markdown document.

        P2-10 (D6, D10): now includes a Run Identification header (run
        ID, persona, tenant, generated_at, final_status), an Acceptance
        Criteria Mapping section (criterion_id, expected, observed,
        status, related step), and a Retest Results section so a
        reviewer can trace every reported result to its run and
        supporting artifact.
        """
        env = report.environment or {}
        lines = [
            f"# QA Test Report: {report.report_id}",
            "",
            f"**Goal:** {report.goal}",
            f"**Status:** {report.status.upper()}",
            f"**Duration:** {report.duration_seconds:.1f}s",
            f"**Started:** {report.started_at.isoformat()}",
            f"**Completed:** {report.completed_at.isoformat() if report.completed_at else 'N/A'}",
            "",
            "---",
            "",
            "## Run Identification",
            "",
            f"- **Run ID:** {env.get('run_id', '')}",
            f"- **Persona:** {env.get('persona', '')}",
            f"- **Verified User:** {env.get('verified_user', env.get('persona_username', 'unverified'))}",
            f"- **Verified Roles:** {env.get('verified_roles', env.get('persona_role', 'unverified'))}",
            f"- **Oracle Mode:** {'persona_constrained' if env.get('oracle_persona_constrained', True) else 'unconstrained'}",
            f"- **Tenant ID:** {env.get('tenant_id', '')}",
            f"- **Generated At:** {env.get('generated_at', '')}",
            f"- **Final Status:** {env.get('final_status', report.status)}",
            "",
            "---",
            "",
            "## Executive Summary",
            "",
            report.summary or "_No summary generated._",
            "",
            "---",
            "",
            "## Validation Results",
            "",
            "| Metric | Count |",
            "|--------|-------|",
            f"| Total  | {report.total_validations} |",
            f"| Passed | {report.passed_validations} |",
            f"| Failed | {report.failed_validations} |",
            f"| Pass Rate | {report.pass_rate:.1f}% |",
            "",
        ]

        # P2-10 (D6, D10): Acceptance Criteria Mapping section — gives a
        # reviewer a per-criterion view of expected vs. observed so they
        # can trace every reported result to its supporting artifact.
        if report.acceptance_criteria_results:
            lines.extend([
                "---",
                "",
                "## Acceptance Criteria Mapping",
                "",
                "| Criterion ID | Field | Expected | Observed | Status | Step |",
                "|--------------|-------|----------|----------|--------|------|",
            ])
            for ac in report.acceptance_criteria_results:
                lines.append(
                    f"| {ac.get('criterion_id', '')} | {ac.get('field', '')} | "
                    f"{ac.get('expected', '')} | {ac.get('observed', '')} | "
                    f"{ac.get('status', '')} | {ac.get('related_step_index', '')} |"
                )
            lines.append("")

        # Defects
        if report.defects:
            lines.extend(
                [
                    "---",
                    "",
                    "## Defects Found",
                    "",
                ]
            )
            for defect in report.defects:
                lines.extend(
                    [
                        f"### {defect.defect_id}: {defect.title}",
                        f"**Severity:** {defect.severity.value}",
                        f"**Description:** {defect.description}",
                        "",
                        f"- **Expected:** {defect.expected_behavior}",
                        f"- **Actual:** {defect.actual_behavior}",
                        f"- **Steps to Reproduce:** {'; '.join(defect.steps_to_reproduce) if getattr(defect, 'steps_to_reproduce', None) else 'N/A'}",
                        f"- **Evidence:** {', '.join(defect.evidence) if getattr(defect, 'evidence', None) else 'None'}",
                        "",
                    ]
                )
                if defect.root_cause_hypothesis:
                    lines.append(f"**Root Cause Hypothesis:** {defect.root_cause_hypothesis}")
                    lines.append("")

        # P1-08 (D7): Retest Results section — preserves BOTH the
        # original finding AND the retest outcome.
        if report.retest_results:
            lines.extend([
                "---",
                "",
                "## Retest Results",
                "",
                "_Each entry preserves the original finding AND the retest "
                "outcome so a fix cannot erase the original defect and a "
                "regression is visible alongside the retest._",
                "",
            ])
            for pkg in report.retest_results:
                lines.extend([
                    f"### Retest {pkg.get('retest_id', '')}",
                    f"- **Original Finding:** {pkg.get('original_finding_id', '')}",
                    f"- **Fix Reference:** {pkg.get('fix_reference', '')}",
                    f"- **Failed Scenario:** {pkg.get('failed_scenario', '')}",
                    f"- **Regression Scenarios:** {', '.join(pkg.get('regression_scenarios', [])) or 'none'}",
                    f"- **Final Status:** {pkg.get('status', '')}",
                ])
                for r in pkg.get("retest_results", []):
                    lines.append(
                        f"  - {r.get('scenario', '')}: {r.get('verdict', '')}"
                    )
                lines.append("")

        # Agent issues (QA engine diagnostics — NOT application defects)
        if report.agent_issues:
            lines.extend(
                [
                    "---",
                    "",
                    "## Agent Issues (QA Engine Diagnostics)",
                    "",
                    "_These are problems encountered by the QA agent itself "
                    "(element location, perception, execution, verification, "
                    "runtime). They are **not** application defects and are "
                    "not counted in the Defects number._",
                    "",
                ]
            )
            for issue in report.agent_issues:
                lines.extend(
                    [
                        f"### {issue.issue_id}: {issue.title} ({issue.category})",
                        f"**Description:** {issue.description}",
                        "",
                    ]
                )

        # Timeline
        lines.extend(
            [
                "---",
                "",
                "## Execution Timeline",
                "",
                "| Step | Action | Result | Duration |",
                "|------|--------|--------|----------|",
            ]
        )
        for entry in report.timeline:
            lines.append(
                f"| {entry.step_index} | {entry.action} | {entry.result} | {entry.duration_ms:.0f}ms |"  # noqa: E501
            )

        # Recommendations
        if report.recommendations:
            lines.extend(
                [
                    "",
                    "---",
                    "",
                    "## Recommendations",
                    "",
                ]
            )
            for rec in report.recommendations:
                lines.append(f"- {rec}")

        return "\n".join(lines)

    async def save_report(self, report: TestReport, format: str = "markdown") -> str:
        """Save the report to disk.

        Args:
            report: The TestReport to save.
            format: Output format ('markdown' or 'json').

        Returns:
            The absolute file path of the saved report.
        """
        if format == "markdown":
            content = await self.render_markdown(report)
            content = redact_string(content)
            extension = "md"
        else:
            # Some report fields intentionally accept arbitrary runtime objects
            # (for example imported test-case models). Pydantic's JSON encoder
            # cannot serialize every such object, so serialize the Python dump
            # with a safe string fallback instead of dropping the JSON artifact.
            try:
                content = report.model_dump_json(indent=2)
            except (TypeError, ValueError):
                content = json.dumps(
                    report.model_dump(mode="python"),
                    default=str,
                    ensure_ascii=False,
                    indent=2,
                )
            content = redact_string(content)
            extension = "json"

        filename = f"{report.report_id}_{report.started_at.strftime('%Y%m%d_%H%M%S')}.{extension}"
        filepath = self._output_dir / filename
        tmp_filepath = self._output_dir / f"{filename}.tmp.{uuid.uuid4().hex[:6]}"

        def _write_report_file() -> None:
            tmp_filepath.write_text(content, encoding="utf-8")
            os.replace(tmp_filepath, filepath)

        await asyncio.to_thread(_write_report_file)

        logger.info("report_saved", path=str(filepath), format=format)
        return str(filepath)

    async def save_xlsx_report(self, report: TestReport, memory: SessionMemory) -> str:
        """Write the run's result back as an XLSX workbook (single test case)."""
        return await self.export_xlsx_results([(report, memory)], suffix=report.report_id)

    async def export_xlsx_results(
        self,
        results: list[tuple[TestReport, SessionMemory]],
        suffix: str | None = None,
    ) -> str:
        """Export one or multiple test-case results into a usable XLSX file.

        Rows follow the 13-column import workbook schema (plus Test Case ID
        and Test Type) and preserve user story ref, test scenario,
        description, test data, preconditions, steps, expected/actual
        results, status, error details, persona, execution metadata, and
        story/sheet traceability.
        """
        import openpyxl

        stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        tag = suffix or f"BATCH-{uuid.uuid4().hex[:8].upper()}"
        filename = f"{tag}_{stamp}.xlsx"
        filepath = self._output_dir / filename
        tmp_filepath = self._output_dir / f"{filename}.tmp.{uuid.uuid4().hex[:6]}"

        wb = openpyxl.Workbook()
        ws = wb.active
        assert ws is not None
        ws.title = "Test Results"

        headers = [
            "Test Case ID", "User Story Ref", "Test Scenario", "Test Case Description",
            "Test Data", "Preconditions", "Steps", "Expected Result", "Actual Result",
            "Status", "Error Details", "Persona", "Test Type",
            "Story Sheet", "Execution Metadata",
        ]
        ws.append(headers)

        for report, memory in results:
            tc = memory.test_case_data or {}
            story_ctx = tc.get("story_context") or {}

            steps_planned = tc.get("ordered_steps") or tc.get("steps") or []
            if steps_planned:
                steps_text = "\n".join(
                    f"{i}. {_step_text(s)}"
                    for i, s in enumerate(steps_planned, 1)
                )
            else:
                steps_text = "\n".join(
                    f"{t.step_index}. {t.action} [{t.result}]" for t in report.timeline
                )

            expected_text = "\n".join(
                str(a.get("description") or a.get("expected_value") or a.get("field") or a)
                if isinstance(a, dict) else str(getattr(a, "description", None) or getattr(a, "expected_value", "") or getattr(a, "field", ""))
                for a in (tc.get("final_assertions") or [])
            )

            actual = (
                "Passed all checks" if report.status == "passed"
                else report.summary or f"Status: {report.status}"
            )

            error_details = "\n".join(
                filter(None, [
                    *[f"{d.severity.value.upper()}: {d.description}" for d in report.defects],
                    *[f"AGENT-ISSUE ({i.category}): {i.description}" for i in report.agent_issues],
                ])
            )

            exec_meta = (
                f"session_id={memory.session_id}; validations={report.total_validations} "
                f"(passed={report.passed_validations}, failed={report.failed_validations}); "
                f"duration={report.duration_seconds:.1f}s"
            )

            row = [
                redact_string(str(tc.get("id", ""))),
                redact_string(str(tc.get("story_id", "") or story_ctx.get("story_ref", ""))),
                redact_string(str(tc.get("title", ""))),
                redact_string(str(tc.get("description") or tc.get("source_user_story") or "")),
                redact_string(_stringify_cell(tc.get("test_data") or "")),
                redact_string("\n".join(tc.get("preconditions") or [])),
                redact_string(steps_text),
                redact_string(expected_text),
                redact_string(actual),
                report.status.upper(),
                redact_string(error_details),
                redact_string(str(getattr(memory, "persona", None) or tc.get("actor_role", ""))),
                tc.get("test_type", "Functional"),
                story_ctx.get("sheet_name", ""),
                redact_string(exec_meta),
            ]
            ws.append(row)

        def _write_xlsx_file() -> None:
            wb.save(tmp_filepath)
            os.replace(tmp_filepath, filepath)

        await asyncio.to_thread(_write_xlsx_file)
        logger.info("xlsx_results_exported", path=str(filepath), rows=len(results))
        return str(filepath)
