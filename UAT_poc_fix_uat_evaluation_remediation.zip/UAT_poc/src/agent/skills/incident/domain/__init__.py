"""Incident domain package."""
