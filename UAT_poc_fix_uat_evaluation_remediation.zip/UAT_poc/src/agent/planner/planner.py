"""Planner — the brain of the autonomous agent.

The planner uses an LLM (Gemini or any OpenAI-compatible provider) to reason
about goals, create execution plans, decide next actions, assess
validations, suggest recovery strategies, and determine when the goal is
complete. It never touches Playwright — it only emits structured actions
that the ExecutionController translates into browser operations.

P1-LAYA: The Planner remains solely responsible for HIGH-LEVEL test
planning — goal decomposition, acceptance criteria, expected outcomes,
and any values already provided by the test case. The LAYA action-policy
adapter (``agent.decision.laya_action_policy``) handles only
BROWSER-LEVEL micro-decisions (which visible control to click/fill/select).
Do not send the whole test-planning job to LAYA — LAYA is a bounded
421M-parameter decision model, not a generative planner. The separation
is:
    Gemini (here)  → plan steps, AC, expected outcomes, report summaries
    LAYA           → "given this plan step + these visible controls,
                      which control should the agent interact with?"
The LAYA path is wired in ``DecisionEngine`` and the orchestrator; this
file is untouched by that integration except for this docstring guard.
"""

from __future__ import annotations

from typing import Any

from agent.core.exceptions import LLMResponseParseError, PlannerError
from agent.core.logging import get_logger
from agent.domain.actions import AgentAction
from agent.domain.knowledge_model import CustomerKnowledgeModel
from agent.domain.observation import PageObservation
from agent.domain.plan import ExecutionPlan
from agent.domain.validation import ValidationCheck, ValidationResult
from agent.memory.session import SessionMemory
from agent.planner.llm_client import BaseLLMClient
from agent.planner.prompts import (
    COMPLETION_CHECK_PROMPT,
    NEXT_ACTION_PROMPT,
    PLAN_GENERATION_PROMPT,
    RECOVERY_PROMPT,
    REPORT_SUMMARY_PROMPT,
    SYSTEM_PROMPT,
    VALIDATION_ASSESSMENT_PROMPT,
)
from agent.testing.generator import ScenarioGenerator, TestScenario
from agent.testing.store import TestIntelligenceStore

logger = get_logger(__name__)


class Planner:
    """The LLM-based reasoning engine.

    Responsibilities:
    - Decompose business goals into execution plans
    - Decide the next action based on observations and memory
    - Assess whether actions achieved their intent
    - Suggest recovery strategies for failures
    - Determine when the goal is complete
    - Generate professional report summaries
    """

    def __init__(
        self,
        llm_client: BaseLLMClient,
        knowledge_context: str = "",
        scenario_generator: ScenarioGenerator | None = None,
        test_store: TestIntelligenceStore | None = None,
        knowledge_model: CustomerKnowledgeModel | None = None,
    ) -> None:
        self._llm = llm_client
        self._knowledge_model = knowledge_model
        km_context = ""
        if knowledge_model and hasattr(knowledge_model, "to_context_str"):
            km_context = knowledge_model.to_context_str()
        self._knowledge_context = knowledge_context or km_context
        self._scenario_generator = scenario_generator
        self._test_store = test_store

    # ── Audit issue I16 (P2) proper fix: public setters so main.py
    # doesn't reach into self._planner._scenario_generator / ._test_store
    # / ._llm directly. Use these setters to honor the encapsulation
    # boundary so future refactors to Planner's internal storage layout
    # don't break AgentOrchestrator's wiring logic.
    def set_scenario_generator(self, generator: "ScenarioGenerator | None") -> None:
        """Attach the scenario generator for test-scenario generation."""
        self._scenario_generator = generator

    def set_test_store(self, store: "TestIntelligenceStore | None") -> None:
        """Attach the test intelligence store."""
        self._test_store = store

    def get_llm_client(self) -> BaseLLMClient:
        """Return the LLM client (read-only accessor for cross-component wiring)."""
        return self._llm

    async def generate_test_scenarios(
        self,
        requirement: str,
        fields: list[dict[str, Any]],
        workflow_type: str | None = None,
        knowledge_model: CustomerKnowledgeModel | None = None,
        table_name: str | None = None,
    ) -> list[TestScenario]:
        """Generate test scenarios dynamically based on strategies."""
        if not self._scenario_generator:
            raise PlannerError("ScenarioGenerator is not initialized.")

        scenarios = await self._scenario_generator.generate_scenarios(
            requirement, fields, workflow_type, knowledge_model, table_name
        )

        # Save to store
        if self._test_store:
            for s in scenarios:
                await self._test_store.save_scenario(s)

        return scenarios

    async def create_plan(self, goal: str, context: str = "") -> ExecutionPlan:
        """Decompose a business goal into an ordered execution plan.

        Args:
            goal: The business-level testing goal.
            context: Additional context (ServiceNow knowledge, etc.)

        Returns:
            An ExecutionPlan with ordered steps.

        Raises:
            PlannerError: If plan generation fails.
        """
        logger.info("creating_plan", goal=goal)

        knowledge = context or self._knowledge_context
        from agent.core.prompt_boundary import LLMInputBoundary
        boundary = LLMInputBoundary(
            system_instructions=SYSTEM_PROMPT,
            verified_intent=PLAN_GENERATION_PROMPT.replace("{untrusted_policy}", "").replace("{goal}", goal).replace("{knowledge_context}", ""),
        )
        boundary.add_untrusted_data("knowledge_context", knowledge)
        prompt = boundary.build_prompt()

        response = await self._llm.complete_json(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )

        try:
            steps_data = response.get("steps", [])
            plan = ExecutionPlan(goal=goal)
            for step_data in steps_data:
                plan.add_step(
                    description=step_data.get("description", ""),
                    expected_outcome=step_data.get("expected_outcome", ""),
                )
            logger.info("plan_created", steps=len(plan.steps))
            return plan
        except Exception as e:
            raise PlannerError(
                f"Failed to parse plan from LLM response: {e}",
                details={"response": response},
            ) from e

    async def decide_next_action(
        self,
        observation: PageObservation,
        memory: SessionMemory,
    ) -> AgentAction:
        """Decide the next action based on current observation and memory.

        This is the core reasoning step in the agent loop. The planner
        considers the current page state, the plan, and recent history
        to choose the optimal next action.

        Args:
            observation: Current page observation.
            memory: Session memory with full context.

        Returns:
            The next AgentAction to execute.
        """
        logger.info("deciding_next_action", step=memory.current_step_index)

        current_step_text = ""
        if memory.plan and memory.plan.current_step:
            step = memory.plan.current_step
            current_step_text = (
                f"Step {step.step_index}: {step.description}\nExpected: {step.expected_outcome}"
            )
        else:
            current_step_text = "No specific plan step — use your judgment based on the goal."

        # Wire PromptBoundary for next action
        from agent.core.prompt_boundary import LLMInputBoundary
        boundary = LLMInputBoundary(
            system_instructions=SYSTEM_PROMPT,
            verified_intent=NEXT_ACTION_PROMPT.replace("{untrusted_policy}", "").replace("{session_context}", "").replace("{current_step}", ""),
        )
        boundary.add_untrusted_data("session_context_dom", memory.get_context_for_llm())
        boundary.add_untrusted_data("current_step", current_step_text)
        prompt = boundary.build_prompt()

        response = await self._llm.complete_json(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )

        try:
            action = self._parse_action(response)
            logger.info(
                "action_decided",
                action_type=action.action_type,
                target=action.target,
                reasoning=action.reasoning[:100],
            )
            return action
        except Exception as e:
            raise PlannerError(
                f"Failed to parse action from LLM response: {e}",
                details={"response": response},
            ) from e

    async def assess_validation(
        self,
        action: AgentAction,
        result: Any,
        before: PageObservation,
        after: PageObservation,
    ) -> ValidationResult:
        """Assess whether an action achieved its intended result.

        Uses the LLM to compare before/after observations and determine
        if the action was successful.

        Args:
            action: The action that was executed.
            result: The ActionResult from execution.
            before: Page observation before the action.
            after: Page observation after the action.

        Returns:
            A ValidationResult with individual checks.
        """
        logger.info("assessing_validation", action=action.action_type)

        # Audit issue I19 (P0): route page-derived text (before/after observations
        # and the action error which may contain page snippets) through the
        # LLMInputBoundary as untrusted data, NOT via str.format — otherwise
        # an attacker controlling ServiceNow record content can redirect the
        # validation assessment via prompt injection.
        from agent.core.prompt_boundary import LLMInputBoundary
        action_success_val = str(result.success if hasattr(result, "success") else True)
        action_error_val = result.error if hasattr(result, "error") else "None"
        boundary = LLMInputBoundary(
            system_instructions=SYSTEM_PROMPT,
            verified_intent=VALIDATION_ASSESSMENT_PROMPT
                .replace("{before_observation}", "")
                .replace("{after_observation}", "")
                .replace("{action_error}", "")
                .replace("{action_description}", f"{action.action_type}: {action.target} → {action.value}")
                .replace("{action_success}", action_success_val),
        )
        boundary.add_untrusted_data("before_observation_dom", before.to_compact_summary())
        boundary.add_untrusted_data("after_observation_dom", after.to_compact_summary())
        boundary.add_untrusted_data("action_error", str(action_error_val))
        prompt = boundary.build_prompt()

        response = await self._llm.complete_json(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )

        try:
            validation = ValidationResult(
                action_description=f"{action.action_type}: {action.target}",
            )
            for check_data in response.get("checks", []):
                check = ValidationCheck(
                    check_name=check_data.get("check_name", "unknown"),
                    description=check_data.get("description", ""),
                    passed=check_data.get("passed", False),
                    expected=check_data.get("expected", ""),
                    actual=check_data.get("actual", ""),
                    error_message=check_data.get("error_message"),
                )
                validation.add_check(check)

            # Ensure overall_passed is set from LLM if no checks
            if not validation.checks:
                validation.overall_passed = response.get("overall_passed", False)

            logger.info(
                "validation_assessed",
                passed=validation.overall_passed,
                checks=len(validation.checks),
            )
            return validation
        except Exception as e:
            raise PlannerError(
                f"Failed to parse validation from LLM response: {e}",
                details={"response": response},
            ) from e

    async def suggest_recovery(
        self,
        error: Exception,
        action: AgentAction,
        observation: PageObservation,
        recovery_history: list[str] | None = None,
    ) -> AgentAction:
        """Suggest a recovery action after a failure.

        The planner analyzes the error context and current page state
        to suggest an alternative action.

        Args:
            error: The exception that occurred.
            action: The action that failed.
            observation: Current page observation.
            recovery_history: Previous recovery attempts.

        Returns:
            A recovery AgentAction to try.
        """
        logger.info("suggesting_recovery", error_type=type(error).__name__)

        history_str = "\n".join(recovery_history) if recovery_history else "None"

        # Audit issue I19 (P0): route page-derived text (current_observation,
        # error_message which may contain Playwright tracebacks with page
        # snippets, and recovery_history which may quote earlier page text)
        # through LLMInputBoundary as untrusted data, NOT via str.format.
        from agent.core.prompt_boundary import LLMInputBoundary
        boundary = LLMInputBoundary(
            system_instructions=SYSTEM_PROMPT,
            verified_intent=RECOVERY_PROMPT
                .replace("{current_observation}", "")
                .replace("{error_message}", "")
                .replace("{recovery_history}", "")
                .replace("{failed_action}", f"{action.action_type}: {action.target} → {action.value}")
                .replace("{error_type}", type(error).__name__),
        )
        boundary.add_untrusted_data("current_observation_dom", observation.to_compact_summary())
        boundary.add_untrusted_data("error_message", str(error))
        boundary.add_untrusted_data("recovery_history", history_str)
        prompt = boundary.build_prompt()

        response = await self._llm.complete_json(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )

        try:
            action = self._parse_action(response)
            logger.info(
                "recovery_suggested",
                action_type=action.action_type,
                reasoning=action.reasoning[:100],
            )
            return action
        except Exception as e:
            raise PlannerError(
                f"Failed to parse recovery action: {e}",
                details={"response": response},
            ) from e

    async def is_goal_complete(self, memory: SessionMemory) -> bool:
        """Determine whether the business goal has been achieved.

        Uses the LLM to analyze the session history and make a
        completion determination.

        Args:
            memory: Session memory with full execution context.

        Returns:
            True if the goal is considered complete.
        """
        logger.info("checking_goal_completion")

        completed_steps_str = "\n".join(
            f"  Step {s.step_index}: {s.action.action_type} → {'✅' if s.result.success else '❌'}"
            for s in memory.completed_steps[-20:]  # Last 20 steps
        )

        # Audit issue I19 (P0): route session_context (page-derived memory)
        # and completed_steps (which may include page-derived error context)
        # through LLMInputBoundary as untrusted data. The goal itself is
        # treated as verified_intent (the authenticated user's explicit API
        # instruction, not page-derived content).
        from agent.core.prompt_boundary import LLMInputBoundary
        boundary = LLMInputBoundary(
            system_instructions=SYSTEM_PROMPT,
            verified_intent=COMPLETION_CHECK_PROMPT
                .replace("{session_context}", "")
                .replace("{completed_steps}", "")
                .replace("{goal}", memory.goal),
        )
        boundary.add_untrusted_data("session_context_dom", memory.get_context_for_llm())
        boundary.add_untrusted_data("completed_steps", completed_steps_str)
        prompt = boundary.build_prompt()

        response = await self._llm.complete_json(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )

        is_complete = response.get("is_complete", False)
        reasoning = response.get("reasoning", "")

        logger.info(
            "goal_completion_check",
            is_complete=is_complete,
            reasoning=reasoning[:200],
        )
        return is_complete  # type: ignore[no-any-return]

    async def generate_report_summary(self, memory: SessionMemory) -> dict[str, Any]:
        """Generate a professional executive summary for the report.

        Args:
            memory: Session memory with full execution context.

        Returns:
            Dict with summary, recommendations, and root_cause_hypotheses.
        """
        logger.info("generating_report_summary")

        defects_str = "None found"
        if memory.failures:
            defects_str = "\n".join(
                f"  - {f.error_type}: {f.error_message}" for f in memory.failures
            )

        passed = sum(1 for v in memory.completed_validations if v.overall_passed)
        failed = sum(1 for v in memory.completed_validations if not v.overall_passed)

        # Audit issue I19 (P0): route session_context (page-derived memory)
        # and defects_summary (page-derived error messages) through
        # LLMInputBoundary as untrusted data. The goal and integer counts
        # are verified_intent / structured data.
        from agent.core.prompt_boundary import LLMInputBoundary
        boundary = LLMInputBoundary(
            system_instructions=SYSTEM_PROMPT,
            verified_intent=REPORT_SUMMARY_PROMPT
                .replace("{session_context}", "")
                .replace("{defects_summary}", "")
                .replace("{goal}", memory.goal)
                .replace("{total_validations}", str(memory.total_validations_run))
                .replace("{passed_validations}", str(passed))
                .replace("{failed_validations}", str(failed)),
        )
        boundary.add_untrusted_data("session_context_dom", memory.get_context_for_llm())
        boundary.add_untrusted_data("defects_summary", defects_str)
        prompt = boundary.build_prompt()

        response = await self._llm.complete_json(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )

        return {
            "summary": response.get("summary", "Report generation failed."),
            "recommendations": response.get("recommendations", []),
            "root_cause_hypotheses": response.get("root_cause_hypotheses", []),
        }

    def _parse_action(self, data: dict[str, Any]) -> AgentAction:
        """Parse an LLM response dict into an AgentAction.

        Handles the various action types and their specific fields.

        Args:
            data: The parsed JSON response from the LLM.

        Returns:
            An AgentAction instance.

        Raises:
            LLMResponseParseError: If the data cannot be parsed.
        """
        action_type = data.get("action_type", "")
        if not action_type:
            raise LLMResponseParseError(
                "LLM response missing 'action_type'",
                details={"data": data},
            )

        return AgentAction(
            action_type=action_type,
            target=data.get("target", ""),
            value=data.get("value", ""),
            reasoning=data.get("reasoning", ""),
            metadata={
                k: v
                for k, v in data.items()
                if k not in ("action_type", "target", "value", "reasoning")
            },
        )
