"""Report models — the final output of an agent run.

Captures the complete execution timeline, validation results, detected
defects, and professional QA summary. Supports rendering to HTML and Markdown.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from agent.core.types import Severity


class TimelineEntry(BaseModel):
    """A single entry in the execution timeline."""

    step_index: int
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    action: str = Field(description="Human-readable action description")
    result: str = Field(description="Outcome: success, failed, skipped")
    duration_ms: float = 0.0
    screenshot_path: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class DefectReport(BaseModel):
    """A detected defect or anomaly found during testing."""

    defect_id: str = Field(description="Unique defect identifier (e.g., DEF-001)")
    severity: Severity = Severity.MEDIUM
    title: str = Field(description="Short defect title")
    description: str = Field(description="Detailed defect description")
    steps_to_reproduce: list[str] = Field(default_factory=list)
    expected_behavior: str = ""
    actual_behavior: str = ""
    evidence: list[str] = Field(
        default_factory=list,
        description="Screenshot paths or log excerpts",
    )
    root_cause_hypothesis: str = Field(
        default="",
        description="LLM-generated hypothesis for the root cause",
    )
    related_step_index: int | None = None


class BrowserLogEntry(BaseModel):
    """A captured browser console or error log entry."""

    level: str = Field(description="log, warn, error, info")
    message: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    source: str = Field(default="console", description="console, network, page_error")


class AgentIssueReport(BaseModel):
    """A diagnostic record of an agent/execution-side problem.

    These are failures of the QA engine itself — element location, perception,
    browser execution, verification, planning, or runtime errors. They are
    deliberately distinct from application defects: an agent issue means the
    engine could not perform/observe/verify, NOT that the ServiceNow
    application misbehaved. They are preserved for engine diagnostics and
    never counted toward the application defect count.
    """

    issue_id: str = Field(description="Unique issue identifier (e.g., AGI-001)")
    title: str = Field(description="Short issue title")
    description: str = Field(description="Detailed issue description")
    category: str = Field(
        default="execution",
        description="execution | perception | verification | planning | runtime",
    )
    related_step_index: int | None = None
    error_type: str | None = Field(
        default=None, description="Exception/error type, if any"
    )


class TestReport(BaseModel):
    """Complete QA test report — the final deliverable of an agent run.

    Aggregates the full execution timeline, all validation results,
    detected defects, browser logs, and a professional summary.
    """

    report_id: str = Field(description="Unique report identifier")
    goal: str = Field(description='The business goal that was tested')
    test_case: Any = Field(default=None, description='The GeneratedTestCase if imported')
    status: str = Field(description="passed, failed, precondition_failed, blocked, error")
    started_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    completed_at: datetime | None = None
    duration_seconds: float = 0.0

    # Timeline
    timeline: list[TimelineEntry] = Field(default_factory=list)

    # Validation
    total_validations: int = 0
    passed_validations: int = 0
    failed_validations: int = 0
    validation_details: list[dict[str, Any]] = Field(default_factory=list)

    # Defects
    defects: list[DefectReport] = Field(default_factory=list)

    # Agent/execution issues — engine diagnostics, NEVER application defects
    agent_issues: list[AgentIssueReport] = Field(default_factory=list)

    # Logs
    browser_logs: list[BrowserLogEntry] = Field(default_factory=list)
    console_errors: list[str] = Field(default_factory=list)

    # Summary
    summary: str = Field(default="", description="LLM-generated executive summary")
    recommendations: list[str] = Field(default_factory=list)

    # INC-UAT-12 (Major, D1/D6): requirement traceability — the set of
    # acceptance-criterion IDs that were covered during this run. Enables
    # the reporting engine to answer "which requirements were tested?".
    requirement_ids_covered: list[str] = Field(
        default_factory=list,
        description="Acceptance-criterion IDs tested during this run.",
    )
    # P0-03 (D1, D6 — AC mapping): per-criterion structured results so a
    # reviewer can see, for every acceptance criterion, its ID, expected
    # result, observed result, and pass/fail/block status. Unknown criteria
    # are reported as BLOCKED, not silently treated as coverage.
    acceptance_criteria_results: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Per-acceptance-criterion result mapping: "
            "[{criterion_id, expected, observed, status, evidence_refs}]. "
            "status ∈ {pass, fail, blocked, not_scored}."
        ),
    )
    # INC-UAT-15 (Minor, D8): exit-criteria engine verdict.
    exit_criteria: dict[str, Any] | None = Field(
        default=None,
        description="Deterministic exit-criteria verdict from IncidentExitCriteriaEngine.",
    )
    # P3-03: reproducibility metadata — stores the exact config version,
    # repo commit, model versions, and manifest hash with every run so
    # results can be reproduced and compared across changes.
    reproducibility: dict[str, Any] | None = Field(
        default=None,
        description="Reproducibility metadata: repo_commit, config_version, model_versions, manifest_hash.",
    )
    # P1-08 (D7): Retest / regression chain results. A fix must not erase
    # the original finding — both the original and the retest outcome are
    # retained here so a reviewer can trace whether the fix resolved the
    # defect AND whether it introduced any regressions.
    retest_results: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Retest package results: "
            "[{retest_id, original_finding_id, fix_reference, failed_scenario, "
            "regression_scenarios, status, retest_results}]. status ∈ "
            "{PENDING, RETESTING, PASSED, FAILED, REGRESSION_DETECTED, INCOMPLETE}."
        ),
    )

    # Metadata
    environment: dict[str, Any] = Field(
        default_factory=dict,
        description="Test environment details and structured run telemetry (URL, browser, metrics, etc.)",
    )
    screenshots: list[str] = Field(
        default_factory=list,
        description="Paths to all captured screenshots",
    )
    video_recording_path: str | None = Field(
        default=None,
        description="Path to recorded video of browser execution if recording was enabled",
    )
    step_evidence: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Step-level evidence chain entries",
    )

    @property
    def has_defects(self) -> bool:
        """Whether any defects were found."""
        return len(self.defects) > 0

    @property
    def defect_count(self) -> int:
        """Number of verified application defects (agent issues excluded)."""
        return len(self.defects)

    @property
    def agent_issue_count(self) -> int:
        """Number of agent-side diagnostic issues."""
        return len(self.agent_issues)

    @property
    def pass_rate(self) -> float:
        """Validation pass rate as a percentage."""
        if self.total_validations == 0:
            return 0.0
        return self.passed_validations / self.total_validations * 100

