"""Validation models — post-action verification results.

After every action, the validation engine runs applicable checks and
produces a ValidationResult. These feed back into the planner's reasoning
and are captured in the final report.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field


class ValidationCheck(BaseModel):
    """A single validation check with expected vs actual comparison."""

    check_name: str = Field(description="Name of the validation check")
    description: str = Field(default="", description="What this check verifies")
    passed: bool = False
    expected: str = Field(default="", description="Expected value or state")
    actual: str = Field(default="", description="Observed value or state")
    evidence: dict[str, Any] = Field(
        default_factory=dict,
        description="Supporting evidence: screenshots, DOM snippets, etc.",
    )
    error_message: str | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))


from enum import Enum

class FailureCategory(str, Enum):
    NETWORK_ERROR = "NETWORK_ERROR"
    ELEMENT_NOT_FOUND = "ELEMENT_NOT_FOUND"
    SEMANTIC_MISMATCH = "SEMANTIC_MISMATCH"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    TIMEOUT = "TIMEOUT"
    UNKNOWN = "UNKNOWN"

class ValidationResult(BaseModel):
    """Aggregated result of all validation checks for a single action.

    Contains the collection of individual checks and an overall pass/fail
    determination.
    """

    action_description: str = Field(
        default="", description="Description of the action that was validated"
    )
    checks: list[ValidationCheck] = Field(default_factory=list)
    overall_passed: bool = False
    classification: str = Field(default="INCONCLUSIVE", description="PASSED, FAILED, INCONCLUSIVE, BLOCKED, CLEANUP_FAILED")
    failure_category: FailureCategory | None = None
    root_cause: str | None = None
    is_precondition_check: bool = False
    precondition_failed: bool = False
    precondition_details: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))

    def add_check(self, check: ValidationCheck) -> None:
        """Add a validation check and recompute overall status."""
        self.checks.append(check)
        self._recompute_overall()

    def _recompute_overall(self) -> None:
        """Recompute overall_passed from individual checks."""
        if not self.checks:
            self.overall_passed = False
            if self.classification not in ("INCONCLUSIVE", "BLOCKED", "CLEANUP_FAILED"):
                self.classification = "FAILED"
            return
        self.overall_passed = all(c.passed for c in self.checks)
        if self.classification not in ("INCONCLUSIVE", "BLOCKED", "CLEANUP_FAILED"):
            self.classification = "PASSED" if self.overall_passed else "FAILED"

    @property
    def passed_checks(self) -> list[ValidationCheck]:
        """Return all checks that passed."""
        return [c for c in self.checks if c.passed]

    @property
    def failed_checks(self) -> list[ValidationCheck]:
        """Return all checks that failed."""
        return [c for c in self.checks if not c.passed]

    def to_summary(self) -> str:
        """Produce a compact text summary for LLM context."""
        total = len(self.checks)
        passed = len(self.passed_checks)
        lines = [
            f"Validation: {'PASSED' if self.overall_passed else 'FAILED'} "
            f"({passed}/{total} checks passed)"
        ]
        for check in self.checks:
            icon = "[PASS]" if check.passed else "[FAIL]"
            lines.append(f"  {icon} {check.check_name}: {check.description}")
            if not check.passed and check.error_message:
                lines.append(f"      Error: {check.error_message}")
        return "\n".join(lines)
